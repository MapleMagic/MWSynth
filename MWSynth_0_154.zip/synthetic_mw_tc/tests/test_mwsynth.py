"""
Regression tests for MWSynth.

RUN: python -m pytest tests/ -v      (or: python tests/test_mwsynth.py)

SCOPE, and why it is this shape: these are regression tests, not a
specification. Almost every case here corresponds to a bug that actually
shipped and was found by staring at an image afterwards -- a saturated
colour plateau, a frozen storm centre, a boiling noise floor, a
longitude sweep across the Atlantic. Each one is cheap to check
automatically and was expensive to notice by eye, which is exactly the
trade a test suite should make.

Nothing here needs network access, credentials, torch, or PyQt6. The
generation path is exercised on small synthetic scenes. The ML
correction is stubbed, because a checkpoint is not a test fixture.

DELIBERATELY NOT COVERED: real data ingest (needs credentials and live
services), GUI construction (needs a display), and model training (needs
torch and a dataset). Those are integration concerns and pretending to
test them here would be theatre.
"""
from __future__ import annotations

import os
import sys
import unittest
from datetime import datetime, timedelta, timezone

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import besttrack  # noqa: E402
import calibration_state  # noqa: E402
import mw_structure_metrics as msm  # noqa: E402
import tc_center_fix  # noqa: E402
from data_types import BandImage, StormFix  # noqa: E402

T0 = datetime(2026, 9, 2, 6, 0, tzinfo=timezone.utc)


def fix_at(hours, lat, lon, **kw):
    base = dict(storm_id="TEST01", vmax_kt=90.0, mslp_mb=960.0, rmw_nm=20.0, roci_nm=150.0)
    base.update(kw)
    return StormFix(valid_time=T0 + timedelta(hours=hours), lat=lat, lon=lon, **base)


def synthetic_scene(n=120, storm_lat=15.0, storm_lon=-95.0, eye_radius_km=0.0):
    lat, lon = np.mgrid[10:20:n * 1j, -100:-90:n * 1j]
    d = np.sqrt((lat - storm_lat) ** 2
                + ((lon - storm_lon) * np.cos(np.radians(storm_lat))) ** 2) * 111.32
    ir = 300.0 - 108.0 * np.exp(-0.5 * (d / 110.0) ** 2)
    if eye_radius_km > 0:
        ir = np.where(d < eye_radius_km, 282.0, ir)
    return lat, lon, ir


def band(values, lat, lon, b=13, t=None):
    return BandImage(band=b, satellite="GOES-19", scene_time=t or T0, values=values,
                     lat=lat, lon=lon, units="K", mesoscale_sector="M1")


def generate(lat, lon, ir, fix, **kw):
    """Run generation with the ML step stubbed out."""
    import ml_inference

    original = ml_inference.apply_ml_correction

    def stub(*a, **k):
        if k.get("stats_out") is not None:
            k["stats_out"].update({"applied": False, "reason": "stubbed for tests"})
        return a[3], a[4], a[5], a[6]

    ml_inference.apply_ml_correction = stub
    try:
        from synthetic_algorithm import generate_synthetic_mw
        return generate_synthetic_mw(band(ir, lat, lon, 13), band(ir + 3, lat, lon, 9),
                                     band(ir + 6, lat, lon, 7), fix, **kw)
    finally:
        ml_inference.apply_ml_correction = original


class TestBestTrackDateline(unittest.TestCase):
    """A storm crossing 180 used to be interpolated to longitude 0 -- the
    Atlantic -- because the naive lon difference read -359 degrees."""

    def test_westward_crossing_takes_short_arc(self):
        fixes = [fix_at(0, 15.0, 179.5), fix_at(6, 15.3, -179.5)]
        mid = besttrack.interpolate_fix(fixes, T0 + timedelta(hours=3))
        self.assertGreater(abs(mid.lon), 179.0,
                           f"interpolated across the dateline to lon {mid.lon}")

    def test_eastward_crossing_takes_short_arc(self):
        fixes = [fix_at(0, 15.0, -179.5), fix_at(6, 15.3, 179.5)]
        mid = besttrack.interpolate_fix(fixes, T0 + timedelta(hours=3))
        self.assertGreater(abs(mid.lon), 179.0)

    def test_extrapolation_wraps(self):
        fixes = [fix_at(0, 15.0, 179.5), fix_at(6, 15.3, -179.5)]
        r = besttrack.interpolate_fix(fixes, T0 + timedelta(hours=9))
        self.assertTrue(-180.0 <= r.lon <= 180.0)
        self.assertGreater(abs(r.lon), 178.0)

    def test_normal_storm_unaffected(self):
        fixes = [fix_at(0, 25.0, -70.0), fix_at(6, 25.6, -71.2)]
        mid = besttrack.interpolate_fix(fixes, T0 + timedelta(hours=3))
        self.assertAlmostEqual(mid.lat, 25.30, places=2)
        self.assertAlmostEqual(mid.lon, -70.60, places=2)


class TestBestTrackExtrapolation(unittest.TestCase):
    """Past the last fix this used to return the endpoint unchanged, so a
    frame five hours after the 06Z fix was built around the 06Z centre."""

    def test_extrapolates_past_last_fix(self):
        fixes = [fix_at(-12, 12.9, -150.1), fix_at(-6, 13.1, -151.0), fix_at(0, 13.35, -151.85)]
        r = besttrack.interpolate_fix(fixes, T0 + timedelta(hours=5))
        self.assertGreater(r.extrapolated_hours, 4.9)
        self.assertLess(r.lon, -151.85, "position did not advance westward")

    def test_does_not_extrapolate_intensity_or_size(self):
        fixes = [fix_at(-6, 13.1, -151.0, vmax_kt=80.0, rmw_nm=25.0),
                 fix_at(0, 13.35, -151.85, vmax_kt=100.0, rmw_nm=20.0)]
        r = besttrack.interpolate_fix(fixes, T0 + timedelta(hours=5))
        self.assertEqual(r.vmax_kt, 100.0, "vmax was extrapolated; it should persist")
        self.assertEqual(r.rmw_nm, 20.0, "RMW was extrapolated; it should persist")

    def test_refuses_beyond_max_gap(self):
        fixes = [fix_at(-6, 13.1, -151.0), fix_at(0, 13.35, -151.85)]
        r = besttrack.interpolate_fix(fixes, T0 + timedelta(hours=20))
        self.assertEqual(r.extrapolated_hours, 0.0, "extrapolated across an implausible gap")

    def test_rejects_implausible_speed(self):
        fixes = [fix_at(-6, 13.0, -151.0), fix_at(0, 13.0, -161.0)]  # ~600 kt
        r = besttrack.interpolate_fix(fixes, T0 + timedelta(hours=3))
        self.assertEqual(r.extrapolated_hours, 0.0)

    def test_degenerate_inputs(self):
        self.assertIsNone(besttrack.interpolate_fix([], T0))
        single = besttrack.interpolate_fix([fix_at(0, 15.0, -95.0)], T0 + timedelta(hours=3))
        self.assertEqual(single.extrapolated_hours, 0.0)


class TestRadialWeight(unittest.TestCase):
    """The eyewall used to land at 1.6-2.2x RMW: the ring width ignored
    RMW, and the ring+envelope sum saturated the clip at 1.0."""

    def _peak_radius(self, rmw_km, vmax_kt, roci_km):
        from synthetic_algorithm import _radial_weight
        n = 400
        lat, lon = np.mgrid[10:20:n * 1j, -100:-90:n * 1j]
        w = _radial_weight(lat, lon, 15.0, -95.0, rmw_km, vmax_kt, roci_km=roci_km)
        d = np.sqrt((lat - 15.0) ** 2
                    + ((lon + 95.0) * np.cos(np.radians(15.0))) ** 2) * 111.32
        edges = np.arange(0, 260, 4)
        prof = [np.nanmean(w[(d >= a) & (d < a + 4)]) for a in edges[:-1]]
        return float(edges[int(np.nanargmax(prof))] + 2)

    def test_eyewall_sits_outward_of_rmw_by_a_bounded_amount(self):
        """REPLACES an "eyewall is near RMW" assertion.

        Best-track RMW is a SURFACE WIND radius, and eyewall convection
        tilts outward with height. Sanabia et al. (2015) measure the lag
        from SFMR and IR along aircraft transects: correlations are most
        negative when the surface winds lag the IR by 10 km, with the IR
        radially OUTWARD -- agreeing with Sanabia et al. (2014) on the
        outward tilt of eyewall convective clouds.

        So a ring sitting exactly on RMW was the wrong target for a
        cloud-top and hydrometeor signature. The property now asserted is
        that it sits outward, by an amount BOUNDED relative to RMW -- the
        10 km figure comes from one typhoon's transects and must not be
        extrapolated into displacing a compact eyewall most of its own
        radius."""
        r = self._peak_radius(19.0, 110.0, 444.0)
        ratio = r / 19.0
        self.assertGreater(ratio, 1.0,
                           f"ring is not outward of RMW ({ratio:.2f}x)")
        self.assertLess(ratio, 1.45,
                        f"ring displaced too far outward: {r:.0f} km for "
                        f"RMW 19 km ({ratio:.2f}x)")

    def test_tilt_is_capped_for_very_compact_storms(self):
        """A fixed 10 km offset is 67% of a 15 km RMW. The cap keeps a
        single-typhoon measurement from being pushed past what it can
        carry."""
        import mw_surface as ms
        for rmw in (10.0, 15.0, 22.0):
            self.assertLessEqual(ms.tilted_ring_radius_km(rmw) / rmw, 1.36)
        # and for a broad storm the full 10 km applies
        self.assertAlmostEqual(ms.tilted_ring_radius_km(111.0), 121.0, places=6)

    def test_eyewall_near_rmw_across_sizes(self):
        for rmw, vmax, roci in [(28.0, 115.0, 463.0), (33.0, 115.0, 463.0),
                                (55.0, 90.0, 300.0), (80.0, 75.0, 350.0)]:
            r = self._peak_radius(rmw, vmax, roci)
            self.assertLess(r / rmw, 1.45, f"RMW {rmw}: eyewall {r:.0f} km ({r/rmw:.2f}x)")

    def test_weight_does_not_saturate(self):
        """A clipped plateau destroys the ring and makes the peak location
        depend on where clipping starts rather than on the storm."""
        from synthetic_algorithm import _radial_weight
        n = 300
        lat, lon = np.mgrid[10:20:n * 1j, -100:-90:n * 1j]
        w = _radial_weight(lat, lon, 15.0, -95.0, 19.0, 110.0, roci_km=444.0)
        frac_at_one = float(np.mean(w >= 1.0 - 1e-9))
        self.assertLess(frac_at_one, 0.001, "radial weight is saturating at 1.0")

    def test_weak_small_storm_produces_a_ring_not_a_disc(self):
        """Edouard: RMW 9 km at 50 kt used to peak at r=0 -- a filled disc."""
        r = self._peak_radius(9.0, 50.0, 167.0)
        self.assertGreater(r, 4.0, "peaked at the centre; no ring formed")


class TestDeterminism(unittest.TestCase):
    """The noise floor used an unseeded RNG, so a frame loop had a
    background that boiled faster than the storm evolved."""

    def test_repeat_generation_is_identical(self):
        lat, lon, ir = synthetic_scene()
        f = fix_at(0, 15.0, -95.0)
        a = generate(lat, lon, ir, f)
        b = generate(lat, lon, ir, f)
        for name in ("v37", "h37", "v89", "h89"):
            np.testing.assert_allclose(getattr(a, name), getattr(b, name),
                                       err_msg=f"{name} differs between identical runs")

    def test_different_storms_get_different_noise(self):
        lat, lon, ir = synthetic_scene()
        a = generate(lat, lon, ir, fix_at(0, 15.0, -95.0, storm_id="EP012026"))
        b = generate(lat, lon, ir, fix_at(0, 15.0, -95.0, storm_id="AL092026"))
        self.assertFalse(np.allclose(a.v89, b.v89),
                         "different storms share a noise field; it looks like a template")


class TestGenerationEdgeCases(unittest.TestCase):
    """None of these should raise, and none should emit unphysical Tb."""

    def _check(self, result):
        for name in ("v37", "h37", "v89", "h89", "freq_37ghz", "freq_89ghz"):
            arr = getattr(result, name)
            self.assertTrue(np.all(np.isfinite(arr)), f"{name} has non-finite values")
            self.assertGreater(float(np.nanmin(arr)), 50.0, f"{name} below 50 K")
            self.assertLess(float(np.nanmax(arr)), 350.0, f"{name} above 350 K")

    def test_storm_outside_grid(self):
        lat, lon, ir = synthetic_scene()
        self._check(generate(lat, lon, ir, fix_at(0, 45.0, -30.0)))

    def test_missing_optional_fields(self):
        lat, lon, ir = synthetic_scene()
        self._check(generate(lat, lon, ir, fix_at(0, 15.0, -95.0, rmw_nm=None, roci_nm=None)))

    def test_extreme_intensities(self):
        lat, lon, ir = synthetic_scene()
        for vmax in (0.0, 200.0):
            self._check(generate(lat, lon, ir, fix_at(0, 15.0, -95.0, vmax_kt=vmax)))

    def test_degenerate_imagery(self):
        lat, lon, ir = synthetic_scene()
        for arr in (np.full_like(ir, 300.0), np.full_like(ir, 190.0), np.full_like(ir, 250.0)):
            self._check(generate(lat, lon, arr, fix_at(0, 15.0, -95.0)))

    def test_tiny_grid(self):
        lat, lon, ir = synthetic_scene(n=6)
        self._check(generate(lat, lon, ir, fix_at(0, 15.0, -95.0)))

    def test_ir_with_nans(self):
        lat, lon, ir = synthetic_scene()
        d = np.sqrt((lat - 15.0) ** 2 + ((lon + 95.0) * np.cos(np.radians(15.0))) ** 2) * 111.32
        self._check(generate(lat, lon, np.where(d < 40, np.nan, ir), fix_at(0, 15.0, -95.0)))


class TestConvectiveSignalWeighting(unittest.TestCase):
    """Cirrus is largely transparent at 37/89 GHz, so a cold canopy with a
    weak WV signature must not score as convection."""

    def _signal(self, wv_mask, scat_pot=0.90, texture=0.30):
        return min(1.0, (0.25 + 0.60 * wv_mask) * scat_pot + 0.15 * texture)

    def test_cirrus_suppressed_relative_to_convection(self):
        deep = self._signal(1.0)
        cirrus = self._signal(0.0)
        self.assertGreater(deep, 0.75, "deep convection should still score high")
        self.assertLess(cirrus, 0.30, "cirrus canopy should be largely transparent")
        self.assertGreater(deep - cirrus, 0.45, "WV mask must actually gate the response")

    def test_coefficients_cannot_saturate(self):
        """Sum to exactly 1.0, so nothing is lost to clipping -- the same
        failure that flattened the eyewall ring in _radial_weight."""
        self.assertAlmostEqual(0.25 + 0.60 + 0.15, 1.0, places=9)


class TestPhysicsProvenance(unittest.TestCase):
    """A residual target is measured against a specific backbone, so mixing
    vintages trains toward neither while every loss curve looks healthy."""

    def test_mixed_vintages_rejected(self):
        import tempfile
        import training_data_export as tde
        d = tempfile.mkdtemp()
        a = os.path.join(d, "A_1.npz")
        b = os.path.join(d, "B_1.npz")
        np.savez(a, vh_physics_id=np.str_("0.99-emission37-cirrusgate"))
        np.savez(b)   # older export, no identifier
        with self.assertRaises(RuntimeError):
            tde.check_physics_consistency([a, b])
        self.assertEqual(len(tde.check_physics_consistency([a])), 1)


class TestS3RangeReader(unittest.TestCase):
    """Reading TC PRIMED in place on S3 is what makes a large training set
    possible on a small disk, so the reader's random access has to be
    exactly right -- a subtle seek bug would corrupt training data
    silently rather than failing."""

    def _reader(self, size=2 * 1024 * 1024, seed=0):
        import io as _io
        import s3_range_reader as srr
        data = np.random.default_rng(seed).bytes(size)

        class MockS3:
            def head_object(self, Bucket, Key):
                return {"ContentLength": len(data)}

            def get_object(self, Bucket, Key, Range=None):
                # Range is OPTIONAL in the real boto3 API; the reader calls
                # without it for small objects. A mock that required it
                # silently pushed the reader down its fallback path.
                if Range is None:
                    return {"Body": _io.BytesIO(data)}
                a, b = Range.split("=")[1].split("-")
                return {"Body": _io.BytesIO(data[int(a):int(b) + 1])}

        return srr.S3RangeReader(MockS3(), "b", "k"), data

    def test_random_access_matches_source(self):
        r, data = self._reader()
        rng = np.random.default_rng(7)
        for _ in range(100):
            off = int(rng.integers(0, len(data) - 1))
            n = int(rng.integers(1, 50000))
            r.seek(off)
            self.assertEqual(r.read(n), data[off:off + n])

    def test_seek_modes(self):
        r, data = self._reader()
        r.seek(0, 2)
        self.assertEqual(r.tell(), len(data))
        r.seek(-100, 2)
        self.assertEqual(r.read(100), data[-100:])
        r.seek(5)
        r.seek(10, 1)
        self.assertEqual(r.tell(), 15)

    def test_read_past_eof_is_short_not_error(self):
        r, data = self._reader()
        r.seek(len(data) - 10)
        self.assertEqual(len(r.read(1000)), 10)

    def test_small_objects_are_fetched_whole_in_one_request(self):
        """Measured on real TC PRIMED files: HDF5 touches ~93% of a
        13-20 MB object anyway, so ranging cost ~30 round trips per file
        and saved ~7% of transfer. One GET is strictly better below the
        size threshold."""
        r, data = self._reader(size=8 * 1024 * 1024)
        r.seek(4 * 1024 * 1024)
        r.read(1000)
        st = r.stats()
        self.assertEqual(st["mode"], "whole")
        self.assertEqual(st["requests"], 1)

    def test_large_objects_still_range(self):
        import s3_range_reader as srr
        r, data = self._reader(size=srr.WHOLE_OBJECT_MAX_BYTES + 2 * 1024 * 1024)
        r.seek(1000)
        r.read(1000)
        self.assertEqual(r.stats()["mode"], "ranged")
        self.assertLess(r.stats()["fetched_fraction"], 0.5)

    def test_buffered_wrapper_matches(self):
        """h5py is handed a BufferedReader, so that path must work too."""
        import io as _io
        r, data = self._reader()
        buf = _io.BufferedReader(r, buffer_size=1024 * 1024)
        buf.seek(1234)
        self.assertEqual(buf.read(50000), data[1234:1234 + 50000])


class TestStreamingHandleOwnership(unittest.TestCase):
    """read_overpass_as_swath must not close a handle it did not open --
    the streamed handle owns an S3 reader the caller still needs for its
    transfer stats, and closing it early would also make the same
    function behave differently depending on how it was called."""

    def test_provided_handle_is_not_closed(self):
        import tcprimed_ingest as tci

        class FakeH5(dict):
            def __init__(self):
                super().__init__()
                self.closed = False

            def close(self):
                self.closed = True

        h = FakeH5()
        # Fails during channel discovery (the fake has no structure), but
        # ownership is decided before that and must hold on the error path
        # too -- which is exactly when a leaked close is easiest to miss.
        try:
            tci.read_overpass_as_swath(None, "GMI", handle=h, label="x")
        except Exception:
            pass
        self.assertFalse(h.closed, "a caller-owned handle was closed")

    def test_rejects_unknown_instrument_before_touching_io(self):
        import tcprimed_ingest as tci
        with self.assertRaises(ValueError):
            tci.read_overpass_as_swath(None, "SSMIS", handle=object())


class TestPipelineCLI(unittest.TestCase):
    """The CLI edits module-level settings in place, so the argument
    handling is worth pinning -- particularly the EXCLUDE_BASINS
    interaction, which would otherwise cancel an explicit basin choice
    and mine nothing while appearing to work."""

    def _import_pipeline(self):
        import types
        for m in ("torch", "torch.nn", "torch.utils", "torch.utils.data"):
            sys.modules.setdefault(m, types.ModuleType(m))
        sys.modules["torch"].nn = sys.modules["torch.nn"]
        sys.modules["torch.nn"].Module = object
        sys.modules["torch"].utils = sys.modules["torch.utils"]
        sys.modules["torch.utils"].data = sys.modules["torch.utils.data"]
        sys.modules["torch.utils.data"].Dataset = object
        sys.modules["torch.utils.data"].DataLoader = object
        sys.modules["torch"].Tensor = object
        sys.modules.setdefault("ml_model", types.SimpleNamespace(MWCorrectionUNet=object))
        sys.modules.setdefault("ml_diffusion", types.SimpleNamespace(MWResidualDiffusion=object))
        import importlib
        import run_ml_pipeline as r
        return importlib.reload(r)

    def _run(self, argv):
        import types
        for m in ("torch", "torch.nn", "torch.utils", "torch.utils.data"):
            sys.modules.setdefault(m, types.ModuleType(m))
        sys.modules["torch"].nn = sys.modules["torch.nn"]
        sys.modules["torch.nn"].Module = object
        sys.modules["torch"].utils = sys.modules["torch.utils"]
        sys.modules["torch.utils"].data = sys.modules["torch.utils.data"]
        sys.modules["torch.utils.data"].Dataset = object
        sys.modules["torch.utils.data"].DataLoader = object
        sys.modules["torch"].Tensor = object
        sys.modules.setdefault("ml_model", types.SimpleNamespace(MWCorrectionUNet=object))
        sys.modules.setdefault("ml_diffusion", types.SimpleNamespace(MWResidualDiffusion=object))
        import importlib
        import run_ml_pipeline as r
        importlib.reload(r)
        r.estimate_mining = lambda: None
        old = sys.argv
        sys.argv = ["x"] + argv + ["--estimate"]
        try:
            r.main()
        except SystemExit:
            pass
        finally:
            sys.argv = old
        return r

    def test_year_range_expands(self):
        r = self._run(["--start", "2018", "--end", "2021"])
        self.assertEqual(r.SEASONS, (2018, 2019, 2020, 2021))

    def test_single_year_when_end_omitted(self):
        self.assertEqual(self._run(["--start", "2022"]).SEASONS, (2022,))

    def test_agency_maps_to_basins(self):
        self.assertEqual(self._run(["--start", "2020", "--agency", "NHC"]).BASINS,
                         ("AL", "EP", "CP"))

    def test_agency_jtwc_clears_the_default_exclusion(self):
        r = self._run(["--start", "2020", "--agency", "JTWC"])
        self.assertEqual(r.BASINS, ("WP", "IO", "SH"))
        for b in r.BASINS:
            self.assertNotIn(b, r.EXCLUDE_BASINS,
                             "default EXCLUDE_BASINS silently cancelled --agency JTWC")

    def test_explicit_basins_override_agency(self):
        r = self._run(["--start", "2020", "--agency", "NHC", "--basins", "AL,WP"])
        self.assertEqual(r.BASINS, ("AL", "WP"))
        self.assertNotIn("WP", r.EXCLUDE_BASINS)

    def test_estimate_actually_calls_the_ingest_api_correctly(self):
        """The earlier CLI tests stubbed estimate_mining() out, so a wrong
        keyword name in the call it makes reached a real run and crashed
        there instead of here. Drive the real function against a fake
        tcprimed_ingest that enforces the true signatures."""
        import types
        import tcprimed_ingest as real_tp

        calls = {"storms": 0, "files": 0}

        def fake_list_available_storms(season_start, season_end=None, basins=None,
                                       version="v01r01", version_type="final",
                                       progress_callback=None):
            calls["storms"] += 1
            return [{"season": season_start, "basin": "AL", "storm_num": 5}]

        def fake_list_storm_overpass_files(basin, storm_num, season,
                                           instrument_filter=None,
                                           version="v01r01", version_type="final"):
            calls["files"] += 1
            return [{"key": f"k/{basin}{storm_num}{season}.nc", "size_bytes": 1234}]

        r = self._import_pipeline()
        saved = (real_tp.list_available_storms, real_tp.list_storm_overpass_files)
        real_tp.list_available_storms = fake_list_available_storms
        real_tp.list_storm_overpass_files = fake_list_storm_overpass_files
        try:
            r.SEASONS = (2022,)
            r.BASINS = ("AL",)
            r.EXCLUDE_BASINS = ()
            r.estimate_mining()          # must not raise
        finally:
            real_tp.list_available_storms, real_tp.list_storm_overpass_files = saved
        self.assertEqual(calls["storms"], 1)
        self.assertEqual(calls["files"], 1)

    def test_estimate_counts_only_supported_instruments(self):
        """TC-PRIMED carries the whole GPM constellation. Counting every
        file over-reported 2022 as 4,245 overpasses and 23 GB when the
        readable subset is a fraction of that -- badly misleading for
        sizing a run."""
        import tcprimed_ingest as tp

        mix = ["GMI"] * 2 + ["AMSR2"] * 2 + ["SSMIS"] * 6 + ["ATMS"] * 5
        saved = (tp.list_available_storms, tp.list_storm_overpass_files)
        tp.list_available_storms = lambda season_start, season_end=None, basins=None, **k: [
            {"season": season_start, "basin": "AL", "storm_num": 1}]
        tp.list_storm_overpass_files = lambda basin, storm_num, season, **k: [
            {"key": f"k/{i}.nc", "size_bytes": 1000, "instrument": inst}
            for i, inst in enumerate(mix)]
        r = self._import_pipeline()
        r.SEASONS, r.BASINS, r.EXCLUDE_BASINS = (2022,), ("AL",), ()
        import io as _io
        import contextlib
        buf = _io.StringIO()
        try:
            with contextlib.redirect_stdout(buf):
                r.estimate_mining()
        finally:
            tp.list_available_storms, tp.list_storm_overpass_files = saved
        out = buf.getvalue()
        self.assertIn("usable overpasses: 4", out)
        self.assertIn("not read: 11", out)

    def test_stream_flag(self):
        self.assertFalse(self._run(["--stream", "false"]).STREAM_FROM_S3)
        self.assertTrue(self._run(["--stream", "true"]).STREAM_FROM_S3)


class TestMiningStreamCallSignature(unittest.TestCase):
    """mine_local_tcprimed_cache's streaming block called the same two
    ingest functions with the same wrong keyword names as
    estimate_mining. Nothing exercised it, so it would have failed on a
    real run after the estimate had already succeeded."""

    def test_stream_block_uses_the_real_signatures(self):
        import inspect
        import ml_data_mining
        import tcprimed_ingest as tp

        src = inspect.getsource(ml_data_mining.mine_local_tcprimed_cache)
        # Names the real functions accept.
        storms_params = set(inspect.signature(tp.list_available_storms).parameters)
        files_params = set(inspect.signature(tp.list_storm_overpass_files).parameters)
        self.assertIn("season_start", storms_params)
        self.assertIn("storm_num", files_params)
        # Names that do NOT exist and previously appeared in the call.
        self.assertNotIn("cyclone_number", files_params)
        self.assertNotIn("cyclone_number=", src,
                         "streaming block still passes a keyword the ingest API "
                         "does not accept")
        self.assertNotIn("list_available_storms(season=", src)
        # And it must filter to readable instruments, or it will spend a
        # ranged GET on every SSMIS/ATMS/MHS file it can never parse.
        self.assertIn("SUPPORTED_INSTRUMENTS", src)


class TestSensorPSF(unittest.TestCase):
    """Before this the 37 and 89 GHz fields had identical spatial
    response, which no real sensor pair has."""

    def _grid(self, n=400):
        return np.mgrid[10:20:n * 1j, -100:-90:n * 1j]

    def test_recovers_published_footprint(self):
        import mw_psf
        lat, lon = self._grid()
        km_row, km_col = mw_psf._grid_spacing_km(lat, lon)
        f = np.zeros((400, 400))
        f[200, 200] = 1.0
        b = mw_psf.apply_sensor_psf(f, lat, lon, 37, "GMI")

        def fwhm(prof, km):
            idx = np.nonzero(prof >= prof.max() / 2)[0]
            return (idx[-1] - idx[0] + 1) * km

        # Published GMI 37 GHz IFOV is 8.6 x 14.0 km; tolerance is a
        # couple of grid cells, since the recovered width is quantized.
        self.assertAlmostEqual(fwhm(b[:, 200], km_row), 8.6, delta=3.0)
        self.assertAlmostEqual(fwhm(b[200], km_col), 14.0, delta=3.0)

    def test_89_is_sharper_than_37(self):
        import mw_psf
        lat, lon = self._grid()
        s37 = mw_psf.psf_sigma_px(lat, lon, 37, "GMI")
        s89 = mw_psf.psf_sigma_px(lat, lon, 89, "GMI")
        self.assertGreater(s37[1], s89[1])

    def test_coarser_sensor_blurs_more(self):
        import mw_psf
        lat, lon = self._grid()
        self.assertGreater(mw_psf.psf_sigma_px(lat, lon, 37, "SSMIS")[1],
                           mw_psf.psf_sigma_px(lat, lon, 37, "AMSR2")[1])

    def test_nan_holes_do_not_bleed(self):
        import mw_psf
        lat, lon = self._grid(100)
        g = np.full((100, 100), 250.0)
        g[40:60, 40:60] = np.nan
        out = mw_psf.apply_sensor_psf(g, lat, lon, 37, "GMI")
        self.assertTrue(np.all(np.isnan(out[45:55, 45:55])))
        self.assertTrue(np.all(np.isfinite(out[:30, :30])))
        self.assertAlmostEqual(float(np.nanmax(np.abs(out[:30, :30] - 250.0))), 0.0, places=6)


class TestCalibrationFit(unittest.TestCase):
    """The constants are ~70% of the residual the correction model is
    asked to absorb, so recovering them exactly from clean data is the
    property that matters."""

    def test_recovers_known_constants(self):
        import calibrate_constants as cc
        from synthetic_algorithm import CALIBRATION as CAL
        import tempfile
        import glob as _glob

        true = dict(CAL)
        true.update({"bg_v_37": 195.0, "emission_boost_v37": 40.0,
                     "max_depression_v37": 15.0, "bg_h_37": 175.0,
                     "emission_boost_h37": 105.0, "max_depression_h37": 8.0,
                     "bg_v_89": 272.0, "max_depression_v89": 95.0,
                     "emission_boost_v89": 7.0, "emission_boost_h89": 16.0,
                     "bg_h_89": 268.0, "max_depression_h89": 115.0})
        rng = np.random.default_rng(0)
        d = tempfile.mkdtemp()
        for i in range(8):
            resp, scat = rng.uniform(0, 1, (48, 48)), rng.uniform(0, 1, (48, 48))
            A, B = resp * (1 - scat), resp * scat
            def mk(c):
                # 89 GHz carries an EMISSION term since 0.133. This
                # generator built it as pure depression, so it encoded the
                # pre-0.133 backbone -- the fifth time a test here has
                # asserted the old model rather than the physics. With the
                # fitter now solving [1, A, -B] for 89 GHz, a
                # depression-only generator is data the model cannot have
                # produced.
                return (c["bg_v_37"] + c["emission_boost_v37"] * A - c["max_depression_v37"] * B,
                        c["bg_h_37"] + c["emission_boost_h37"] * A - c["max_depression_h37"] * B,
                        c["bg_v_89"] + c.get("emission_boost_v89", 0.0) * A
                        - c["max_depression_v89"] * B,
                        c["bg_h_89"] + c.get("emission_boost_h89", 0.0) * A
                        - c["max_depression_h89"] * B)
            bv37, bh37, bv89, bh89 = mk(CAL)
            tv37, th37, tv89, th89 = mk(true)
            np.savez(os.path.join(d, f"S{i}_1.npz"),
                     backbone_v37=bv37, backbone_h37=bh37,
                     backbone_v89=bv89, backbone_h89=bh89,
                     target_v37=tv37, target_h37=th37,
                     target_v89=tv89, target_h89=th89,
                     mask=np.ones((48, 48), np.float32))
        res = cc.fit_from_examples(sorted(_glob.glob(os.path.join(d, "*.npz"))), CAL)
        for k in list(cc.PARAMS_37) + list(cc.PARAMS_89):
            self.assertAlmostEqual(res["fitted"][k], true[k], delta=0.5, msg=k)
        for k in ("emission_boost_v89", "emission_boost_h89"):
            self.assertAlmostEqual(res["fitted"][k], true[k], delta=0.5, msg=k)
        for k in ("v37", "h37", "v89", "h89"):
            self.assertLess(res["after_rmse_k"][k], res["before_rmse_k"][k])

    def test_collinear_constants_raise_rather_than_return_garbage(self):
        import calibrate_constants as cc
        bad = {"emission_boost_v37": 10.0, "max_depression_v37": 10.0,
               "emission_boost_h37": 20.0, "max_depression_h37": 20.0,
               "bg_v_37": 200.0, "bg_h_37": 180.0}
        with self.assertRaises(ValueError):
            cc.recover_weights_37(np.zeros(4), np.zeros(4), bad)


class TestGLMLightning(unittest.TestCase):
    def test_flashes_land_on_the_right_pixel(self):
        import glm_lightning as g
        import goes_fetch
        from datetime import datetime, timezone
        lat, lon = np.mgrid[20:10:200j, -100:-90:200j]
        rng = np.random.default_rng(0)
        # SAVE and restore, never delete. This originally deleted the
        # attribute, which was harmless when goes_fetch had no GLM reader
        # -- once 0.129 added one, the test destroyed it for every test
        # that ran afterwards. Classic order-dependent pollution, caught
        # by a later test asserting the reader exists.
        _saved = getattr(goes_fetch, "get_glm_flashes", None)
        goes_fetch.get_glm_flashes = lambda sat, t0, t1: (
            rng.normal(15.0, 0.2, 400), rng.normal(-95.0, 0.2, 400), np.ones(400))
        try:
            d = g.flash_density_grid(lat, lon, "GOES-19",
                                     datetime(2026, 9, 2, 16, tzinfo=timezone.utc))
        finally:
            if _saved is not None:
                goes_fetch.get_glm_flashes = _saved
            else:
                del goes_fetch.get_glm_flashes
        r, c = np.unravel_index(np.argmax(d), d.shape)
        self.assertAlmostEqual(float(lat[r, c]), 15.0, delta=0.4)
        self.assertAlmostEqual(float(lon[r, c]), -95.0, delta=0.4)

    def test_missing_glm_gives_zeros_not_an_error(self):
        """Absent GLM must produce the same field a lightning-free scene
        does, so the model's input distribution does not shift with
        product availability."""
        import glm_lightning as g
        from datetime import datetime, timezone
        lat, lon = np.mgrid[20:10:50j, -100:-90:50j]
        d = g.flash_density_grid(lat, lon, "GOES-19",
                                 datetime(2026, 9, 2, 16, tzinfo=timezone.utc))
        self.assertEqual(d.shape, lat.shape)
        self.assertTrue(np.all(d == 0))

    def test_normalization_compresses_the_tail(self):
        import glm_lightning as g
        a = np.array([0.0, 1.0, 10.0, 100.0], dtype=np.float32)
        n = g.normalize_for_model(a)
        self.assertEqual(float(n[0]), 0.0)
        self.assertTrue(np.all(np.diff(n) > 0))
        self.assertLess(float(n[-1]), 2.0)


class TestParallax(unittest.TestCase):
    """GOES sees a 12-16 km cloud top displaced 4-13 km from its true
    ground position. The MW target does not share that displacement, so
    uncorrected it becomes a systematic offset the correction model has
    to absorb."""

    def test_zenith_exceeds_central_angle(self):
        """parallax uses the satellite ZENITH angle; goes_fetch's
        _view_angle_deg is the Earth-CENTRAL angle. Confusing the two
        under-corrects by 15-20%, so the relationship is pinned."""
        import parallax as px
        import goes_fetch as gf
        for sat, lat, lon in [(-137.0, 13.5, -153.0), (-75.2, 29.0, -94.0)]:
            zen = float(px.view_angle_deg(sat, np.array(lat), np.array(lon)))
            cen = gf._view_angle_deg(sat, lat, lon)
            self.assertGreater(zen, cen)
            self.assertLess(zen - cen, 15.0)

    def test_nadir_has_no_displacement(self):
        import parallax as px
        dlat, dlon = px.parallax_offsets(np.array(0.0), np.array(-137.0),
                                         np.array(15.0), -137.0)
        self.assertAlmostEqual(float(dlat), 0.0, places=4)
        self.assertAlmostEqual(float(dlon), 0.0, places=4)

    def test_uniform_height_shift_matches_geometry(self):
        """With uniform cloud height the shift must equal h*tan(zenith)."""
        import math
        import parallax as px
        n = 301
        lat, lon = np.mgrid[20:10:n * 1j, -160:-146:n * 1j]
        d = np.sqrt((lat - 15.0) ** 2
                    + ((lon + 153.0) * np.cos(np.radians(15.0))) ** 2) * 111.32
        blob = np.exp(-0.5 * (d / 60.0) ** 2)
        flat_ir = np.full_like(lat, 200.0)
        corr = px.correct_field(blob, lat, lon, flat_ir, -137.0)

        def cen(f):
            w = f / f.sum()
            return float((lat * w).sum()), float((lon * w).sum())

        la, lo = cen(blob)
        lb, lob = cen(corr)
        h = float(px.cloud_top_height_km(np.array(200.0)))
        th = float(px.view_angle_deg(-137.0, np.array(15.0), np.array(-153.0)))
        expected = h * math.tan(math.radians(th))
        got = math.hypot(lb - la, (lob - lo) * math.cos(math.radians(la))) * 111.32
        self.assertAlmostEqual(got, expected, delta=0.5)
        # and toward the subsatellite point
        self.assertLess(lb, la)
        self.assertGreater(lob, lo)

    def test_height_is_capped_at_the_tropopause(self):
        """Above the tropopause colder no longer means higher; an
        overshooting top would otherwise be placed absurdly high."""
        import parallax as px
        self.assertLessEqual(float(px.cloud_top_height_km(np.array(180.0))),
                             px.MAX_CLOUD_TOP_KM)
        self.assertAlmostEqual(float(px.cloud_top_height_km(np.array(305.0))), 0.0)

    def test_warm_pixels_barely_move(self):
        """A warm eye is low, so it displaces far less than the cold tops
        around it -- the reason this is done per-pixel, not per-scene."""
        import parallax as px
        lat = np.array([15.0, 15.0])
        lon = np.array([-153.0, -153.0])
        h = px.cloud_top_height_km(np.array([290.0, 200.0]))
        dlat, dlon = px.parallax_offsets(lat, lon, h, -137.0)
        self.assertLess(abs(float(dlat[0])), abs(float(dlat[1])) / 5)


class TestFrequencyResponseAndWind(unittest.TestCase):
    def test_89_response_is_more_concentrated_than_37(self):
        """89 GHz sees ice (threshold-like, peaked); 37 GHz sees liquid
        (deep and diffuse). Before 0.114 these were the same array."""
        import mw_surface as ms
        lat, lon = np.mgrid[20:10:200j, -160:-146:200j]
        d = np.sqrt((lat - 15.0) ** 2
                    + ((lon + 153.0) * np.cos(np.radians(15.0))) ** 2) * 111.32
        resp = np.exp(-0.5 * (d / 80.0) ** 2)
        r37 = ms.frequency_response(resp, 37, lat, lon)
        r89 = ms.frequency_response(resp, 89, lat, lon)
        self.assertGreater(ms.concentration(r89), ms.concentration(r37))
        self.assertFalse(np.allclose(r37, r89))

    def test_wind_profile_peaks_at_the_rmw(self):
        import mw_surface as ms
        r = np.linspace(1, 400, 400)
        u = ms.surface_wind_ms(r, vmax_kt=110.0, rmw_km=30.0)
        self.assertAlmostEqual(float(r[np.argmax(u)]), 30.0, delta=2.0)
        self.assertGreaterEqual(float(u[-1]), ms.AMBIENT_WIND_MS)

    def test_h_pol_roughens_more_than_v_pol(self):
        """H-pol starts far from unity so wind moves it much more; this
        asymmetry is the whole reason the effect matters here."""
        import mw_surface as ms
        u = np.array(45.0)
        self.assertGreater(float(ms.roughening_k(u, 37, "h")),
                           2 * float(ms.roughening_k(u, 37, "v")))

    def test_roughening_is_capped_and_suppressed_over_land(self):
        import mw_surface as ms
        self.assertLessEqual(float(ms.roughening_k(np.array(120.0), 37, "h")),
                             ms.MAX_ROUGHENING_K[37]["h"] + 1e-6)
        land = ms.roughening_k(np.array(45.0), 37, "h", land_fraction=np.array(1.0))
        self.assertAlmostEqual(float(land), 0.0, places=6)

    def test_ambient_wind_adds_nothing(self):
        """Referenced to ambient, so the far field reproduces the
        constant rather than drifting away from the measured value."""
        import mw_surface as ms
        inc = ms.roughening_k(np.array(ms.AMBIENT_WIND_MS), 37, "h")
        self.assertAlmostEqual(float(inc), 0.0, places=6)


class TestDatetimeAwarenessBoundary(unittest.TestCase):
    """A naive/aware mismatch here cost a full mining run: TC PRIMED scene
    times became tz-aware in 0.105 while goes_fetch's era table and parsed
    filenames stayed naive. 4,867 overpasses attempted, 0 saved, every one
    a TypeError."""

    def test_select_satellite_accepts_aware_and_naive(self):
        import goes_fetch as gf
        from datetime import datetime, timezone
        aware = datetime(2022, 9, 2, 16, 0, tzinfo=timezone.utc)
        naive = datetime(2022, 9, 2, 16, 0)
        self.assertEqual(gf.select_satellite(15.0, -95.0, aware),
                         gf.select_satellite(15.0, -95.0, naive))

    def test_era_table_is_tz_aware(self):
        import goes_fetch as gf
        for era in gf.SATELLITE_ERAS:
            for bound in (era[2], era[3]):
                self.assertIsNotNone(bound.tzinfo,
                                     "era bound is naive; will TypeError against "
                                     "the project's aware timestamps")

    def test_parsed_filename_times_are_aware(self):
        """GOES filenames are UTC by definition; returning naive only
        defers the failure to whichever comparison comes first."""
        import goes_fetch as gf
        import inspect
        src = inspect.getsource(gf)
        self.assertIn("tzinfo=timezone.utc", src)

    def test_as_utc_is_idempotent(self):
        import goes_fetch as gf
        from datetime import datetime, timezone
        aware = datetime(2022, 9, 2, 16, 0, tzinfo=timezone.utc)
        self.assertEqual(gf._as_utc(gf._as_utc(aware)), aware)
        self.assertIsNotNone(gf._as_utc(datetime(2022, 9, 2, 16, 0)).tzinfo)


class TestDatetimeConvention(unittest.TestCase):
    """One convention, enforced project-wide: tz-aware UTC.

    The mixture cost two full mining runs -- 4,867 attempted / 0 saved,
    then 613 / 0 saved -- and patching one boundary at a time made it
    worse: fixing TC PRIMED moved the clash to goes_fetch, fixing
    goes_fetch moved it to best track. These tests check the CONVENTION
    rather than any individual site, because that was the actual defect.
    """

    AWARE = datetime(2022, 9, 2, 16, 0, tzinfo=timezone.utc)
    NAIVE = datetime(2022, 9, 2, 16, 0)

    def _fixes(self, aware=True):
        base = self.AWARE if aware else self.NAIVE
        return [StormFix(storm_id="AL092022",
                         valid_time=base + timedelta(hours=h),
                         lat=25.0 + h * 0.1, lon=-70.0 - h * 0.2,
                         vmax_kt=90.0, mslp_mb=960.0, rmw_nm=25.0, roci_nm=200.0)
                for h in (-6, 0, 6)]

    def test_as_utc_is_idempotent_and_upgrades_naive(self):
        import timeutil
        self.assertEqual(timeutil.as_utc(timeutil.as_utc(self.AWARE)), self.AWARE)
        self.assertEqual(timeutil.as_utc(self.NAIVE), self.AWARE)
        self.assertIsNone(timeutil.as_utc(None))

    def test_interpolate_fix_accepts_every_combination(self):
        """This one comparison is where every mined overpass passes, and
        it failed 613 times in a row."""
        import besttrack
        for fixes_aware in (True, False):
            for target in (self.AWARE, self.NAIVE):
                r = besttrack.interpolate_fix(self._fixes(fixes_aware), target)
                self.assertIsNotNone(r)
                self.assertIsNotNone(r.valid_time.tzinfo,
                                     "interpolate_fix returned a naive time")

    def test_goes_fetch_accepts_both(self):
        import goes_fetch as gf
        self.assertEqual(gf.select_satellite(25.0, -70.0, self.AWARE),
                         gf.select_satellite(25.0, -70.0, self.NAIVE))

    def test_solar_accepts_both(self):
        import solar
        self.assertEqual(solar.is_daytime(15.0, -95.0, self.AWARE),
                         solar.is_daytime(15.0, -95.0, self.NAIVE))

    def test_no_module_strips_tzinfo(self):
        """`.replace(tzinfo=None)` is how the naive convention crept back
        in three separate modules. Only timeutil may do it, and only in
        as_naive_utc()."""
        import glob as _glob
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        offenders = []
        for path in _glob.glob(os.path.join(src_dir, "**", "*.py"), recursive=True):
            if os.path.basename(path) == "timeutil.py":
                continue
            with open(path, encoding="utf-8") as fh:
                for i, line in enumerate(fh, 1):
                    st = line.strip()
                    if st.startswith("#") or "naive-ok" in line:
                        # Explicit opt-out, for code that constructs a
                        # naive value on purpose -- e.g. preflight, which
                        # must build the bad input to test for it. The
                        # marker has to be deliberate, so an accidental
                        # strip still fails.
                        continue
                    if "replace(tzinfo=None)" in line:
                        offenders.append(f"{os.path.basename(path)}:{i}")
        self.assertEqual(offenders, [], f"tzinfo stripped outside timeutil: {offenders}")

    def test_no_deprecated_naive_utc_helpers(self):
        """utcnow()/utcfromtimestamp() are deprecated from 3.12 and return
        naive values, which is what started this."""
        import glob as _glob
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        offenders = []
        for path in _glob.glob(os.path.join(src_dir, "**", "*.py"), recursive=True):
            # timeutil documents the deprecated helpers it replaces, so it
            # legitimately names them in prose.
            if os.path.basename(path) == "timeutil.py":
                continue
            with open(path, encoding="utf-8") as fh:
                for i, line in enumerate(fh, 1):
                    st = line.strip()
                    if st.startswith("#"):
                        continue
                    if "datetime.utcnow(" in st or "datetime.utcfromtimestamp(" in st:
                        offenders.append(f"{os.path.basename(path)}:{i}")
        self.assertEqual(offenders, [], f"deprecated naive helpers: {offenders}")


class TestMiningRobustness(unittest.TestCase):
    """Two runs were lost grinding to completion while failing identically
    on every attempt. These check the guards that stop that."""

    def test_export_skips_an_existing_current_vintage_file(self):
        """Resumability: an interrupted multi-hour mine must not redo work
        already on disk, or a dropped connection costs the whole run."""
        import tempfile
        import training_data_export as tde
        d = tempfile.mkdtemp()
        path = os.path.join(d, "AL012022_202209021600_GMI.npz")
        np.savez(path, vh_physics_id=np.str_(tde._vh_physics_id()), dummy=np.zeros(2))
        before = os.path.getmtime(path)
        self.assertTrue(os.path.exists(path))
        with np.load(path, allow_pickle=True) as dd:
            self.assertEqual(str(dd["vh_physics_id"]), tde._vh_physics_id())
        self.assertEqual(os.path.getmtime(path), before)

    def test_stale_vintage_file_is_not_reused(self):
        """A file from a superseded backbone must be redone, not skipped,
        or the dataset silently mixes vintages."""
        import tempfile
        import training_data_export as tde
        d = tempfile.mkdtemp()
        path = os.path.join(d, "AL012022_202209021600_GMI.npz")
        np.savez(path, vh_physics_id=np.str_("0.01-ancient"))
        with np.load(path, allow_pickle=True) as dd:
            self.assertNotEqual(str(dd["vh_physics_id"]), tde._vh_physics_id())

    def test_abort_thresholds_are_sane(self):
        import ml_data_mining as m
        self.assertGreaterEqual(m.ABORT_CHECK_AFTER, 50)
        self.assertGreater(m.ABORT_DOMINANCE, 0.8)
        self.assertLessEqual(m.ABORT_DOMINANCE, 1.0)


class TestChannelNormalization(unittest.TestCase):
    """A normalization mismatch between training and inference throws no
    error -- it just produces quietly wrong corrections. One shared
    implementation is the only reliable defence."""

    def test_train_and_inference_both_delegate_to_the_shared_function(self):
        """ml_train imports torch, and this suite is deliberately
        torch-free, so the equivalence is pinned structurally: both
        modules must DELEGATE rather than carry their own arithmetic.
        That is the actual property -- duplicated arithmetic is what
        allows the two to drift apart later."""
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        for module in ("ml_train.py", "ml_inference.py"):
            with open(os.path.join(src_dir, module), encoding="utf-8") as fh:
                src = fh.read()
            self.assertIn("normalize_channel", src,
                          f"{module} does not use the shared normalizer")
            # No local re-implementation of the old global formula.
            self.assertNotIn("- TB_MEAN) / TB_STD", src,
                             f"{module} still normalizes inline; it can drift "
                             f"from the shared implementation")

    def test_shared_normalizer_is_channel_specific(self):
        from ml_constants import normalize_channel
        a = np.array([250.0], dtype=np.float32)
        self.assertNotAlmostEqual(float(normalize_channel(a, "wv")[0]),
                                  float(normalize_channel(a, "ir")[0]), places=3)

    def test_round_trip(self):
        from ml_constants import normalize_channel, denormalize_channel
        a = np.linspace(150.0, 300.0, 32).astype(np.float32)
        for ch in ("ir", "wv", "backbone_h37"):
            np.testing.assert_allclose(
                denormalize_channel(normalize_channel(a, ch), ch), a, rtol=1e-5)

    def test_every_layout_channel_is_reasonably_conditioned(self):
        """Each Tb channel should span roughly +/-1-2 sigma over its
        physical range, not sit entirely on one side of zero -- which is
        what the single global (260, 40) did to the water-vapour bands."""
        from ml_constants import normalize_channel, CHANNEL_NORM
        ranges = {"ir": (190, 300), "wv": (205, 265), "swir": (200, 300),
                  "backbone_v37": (240, 285), "backbone_h37": (150, 280),
                  "backbone_v89": (180, 300), "backbone_h89": (150, 290),
                  "ir_band8": (215, 250), "ir_band9": (215, 260),
                  "ir_band10": (215, 265), "ir_band11": (195, 300),
                  "ir_band12": (200, 285), "ir_band14": (190, 300),
                  "ir_band15": (190, 300), "ir_band16": (205, 285)}
        for ch, (lo, hi) in ranges.items():
            self.assertIn(ch, CHANNEL_NORM, f"{ch} has no explicit norm")
            n = normalize_channel(np.array([lo, hi], dtype=np.float32), ch)
            self.assertLess(n[0], 0.0, f"{ch} never goes negative")
            self.assertGreater(n[1], 0.0, f"{ch} never goes positive")
            self.assertLess(abs(float(n[0])), 4.0, f"{ch} low end is extreme")
            self.assertLess(abs(float(n[1])), 4.0, f"{ch} high end is extreme")

    def test_unknown_channel_falls_back_rather_than_raising(self):
        from ml_constants import normalize_channel, CHANNEL_NORM_DEFAULT
        a = np.array([260.0], dtype=np.float32)
        got = float(normalize_channel(a, "channel_added_next_year")[0])
        self.assertAlmostEqual(
            got, (260.0 - CHANNEL_NORM_DEFAULT[0]) / CHANNEL_NORM_DEFAULT[1], places=5)


class TestNoTargetLeakIntoBackbone(unittest.TestCase):
    """The stored backbone must equal what a GOES-ONLY frame produces.

    `baseline_shift_*` is measured from the current frame's real MW and
    added to the backbone, clamped to +/-20 K. Every training example has
    real MW; no GOES-only frame does. Leaving the shift in the stored
    backbone both leaked the target into the input -- so the model learned
    a smaller correction than GOES-only needs -- and created a
    train/inference mismatch in exactly the mode this tool exists for. The
    clamp is 20 K against a measured bias of 11.5 K.
    """

    def _frame(self, with_mw):
        from data_types import BandImage, StormFix, MWSwath
        from synthetic_algorithm import generate_synthetic_mw
        t = datetime(2022, 9, 2, 16, tzinfo=timezone.utc)
        n = 140
        lat, lon = np.mgrid[20:8:n * 1j, -162:-144:n * 1j]
        d = np.sqrt((lat - 14.0) ** 2
                    + ((lon + 153.0) * np.cos(np.radians(14.0))) ** 2) * 111.32
        ir = np.where(d < 20, 282.0, 300.0 - 110.0 * np.exp(-0.5 * (d / 110.0) ** 2))
        mk = lambda v, b: BandImage(band=b, satellite="GOES-18", scene_time=t,
                                    values=v, lat=lat, lon=lon, units="K",
                                    mesoscale_sector="M1")
        fx = StormFix(storm_id="X", valid_time=t, lat=14.0, lon=-153.0,
                      vmax_kt=110.0, mslp_mb=950.0, rmw_nm=19.0, roci_nm=240.0)
        sw = None
        if with_mw:
            # far field deliberately offset from the assumed background,
            # so a non-zero shift is actually measured
            sw = MWSwath(sensor="GMI", scene_time=t, lat=lat, lon=lon,
                         v37=np.full((n, n), 265.0), h37=np.full((n, n), 197.0),
                         v89=np.full((n, n), 275.0), h89=np.full((n, n), 268.0),
                         source_note="synthetic")
        r = generate_synthetic_mw(mk(ir, 13), mk(ir + 3, 9), mk(ir + 6, 7), fx,
                                  real_swath=sw)
        return r, d

    def test_a_shift_is_actually_measured(self):
        """Guards against the test passing because the shift is zero."""
        r, _ = self._frame(with_mw=True)
        bs = r.diagnostics["baseline_shift_k"]
        self.assertGreater(max(abs(v) for v in bs.values()), 5.0)

    def test_stored_backbone_matches_the_goes_only_field(self):
        with_mw, d = self._frame(with_mw=True)
        goes_only, _ = self._frame(with_mw=False)
        far = d > 500
        for name in ("h37", "v37", "h89", "v89"):
            stored = float(np.nanmedian(np.asarray(with_mw.diagnostics[f"backbone_{name}"])[far]))
            plain = float(np.nanmedian(getattr(goes_only, name)[far]))
            self.assertAlmostEqual(stored, plain, delta=1.5,
                                   msg=f"{name}: stored backbone carries the "
                                       f"baseline shift, which GOES-only never sees")

    def test_goes_only_records_zero_shift(self):
        r, _ = self._frame(with_mw=False)
        self.assertEqual(set(r.diagnostics["baseline_shift_k"].values()), {0.0})


class TestIceCouplingDiagnostic(unittest.TestCase):
    """Measures a physics question from the mined data instead of
    guessing at it.

    Li et al. describe 37 GHz emission being "only partially attenuated by
    the ice layer above" -- a coupling this backbone does not model, since
    37 and 89 GHz are computed independently. Checking it against rendered
    NRL imagery came back AMBIGUOUS: the deepest-ice class was ~6,700
    pixels and an RGB threshold may exclude the very hottest 37H pixels,
    so a low emitting-fraction could mean screening OR its opposite.

    The mined .npz files hold both Tb fields on the same grid, so the
    question is directly measurable. This must distinguish the two cases,
    or it is worse than not asking."""

    def _dataset(self, screening):
        import glob as _glob
        import tempfile
        rng = np.random.default_rng(0)
        d = tempfile.mkdtemp()
        for f in range(5):
            n = 48
            t89 = rng.uniform(150, 300, (n, n))
            base = 200 + 70 * np.clip((300 - t89) / 150, 0, 1)
            if screening:
                base = base - 60 * np.clip((212 - t89) / 62, 0, 1)
            t37 = base + rng.normal(0, 2, (n, n))
            np.savez(os.path.join(d, f"S{f}_1.npz"),
                     target_h37=t37.astype(np.float32),
                     target_h89=t89.astype(np.float32),
                     mask=np.ones((n, n), np.float32))
        return sorted(_glob.glob(os.path.join(d, "*.npz")))

    def _deep_vs_mid(self, res):
        deep = [r for r in res["bins"] if r["h89_range"][1] <= 212]
        mid = [r for r in res["bins"] if 212 <= r["h89_range"][0] < 254]
        return (float(np.mean([r["h37_median"] for r in deep])),
                float(np.mean([r["h37_median"] for r in mid])))

    def test_detects_screening(self):
        import calibrate_constants as cc
        deep, mid = self._deep_vs_mid(
            cc.ice_coupling_profile(self._dataset(screening=True)))
        self.assertLess(deep, mid - 3.0)

    def test_detects_absence_of_screening(self):
        """The failure that matters: reporting screening where there is
        only co-variation would motivate a term the data does not support."""
        import calibrate_constants as cc
        deep, mid = self._deep_vs_mid(
            cc.ice_coupling_profile(self._dataset(screening=False)))
        self.assertGreater(deep, mid + 3.0)

    def test_handles_packed_and_empty_input(self):
        import calibrate_constants as cc
        self.assertEqual(cc.ice_coupling_profile([])["n_files"], 0)


class TestSaturationAndFreezingLevel(unittest.TestCase):
    """A linear response-to-Tb ramp is too weak everywhere below full
    response -- a one-signed error over the bulk of every frame, which is
    what an unexplained bias that more data cannot fix looks like."""

    def test_endpoints_are_preserved(self):
        """Existing constants keep their meaning, and calibrate_constants
        keeps working -- it solves for the PRODUCTS resp*(1-scat) and
        resp*scat, so substituting sat(resp) leaves that algebra alone."""
        import mw_surface as ms
        self.assertAlmostEqual(float(ms.saturate(0.0)), 0.0, places=9)
        self.assertAlmostEqual(float(ms.saturate(1.0)), 1.0, places=9)

    def test_curve_is_concave_not_linear(self):
        """Asserts the PROPERTY, not a magnitude.

        The first version required a 1.2x lift at mid-range, which was
        calibrated to SATURATION_K = 3.0 -- so lowering that constant to a
        defensible interim failed a test that was pinning a tunable, not a
        physical fact. The fact is that emission saturates: the curve must
        sit above the diagonal and be concave. How far above is exactly
        what calibrate_constants should decide."""
        import mw_surface as ms
        r = np.linspace(0.05, 0.95, 19)
        v = ms.saturate(r)
        self.assertTrue(np.all(v > r), "saturation curve is not above linear")
        # concave: second difference negative throughout
        self.assertTrue(np.all(np.diff(v, 2) < 0), "curve is not concave")

    def test_monotonic(self):
        import mw_surface as ms
        v = ms.saturate(np.linspace(0, 1, 40))
        self.assertTrue(np.all(np.diff(v) > 0))

    def test_freezing_level_reduces_ice_poleward(self):
        """The freezing level drops poleward, so the same cloud top
        implies less ice aloft at 35 degrees than in the deep tropics."""
        import mw_surface as ms
        trop = float(ms.ice_depth_factor(np.array(10.0)))
        mid = float(ms.ice_depth_factor(np.array(35.0)))
        self.assertAlmostEqual(trop, 1.0, delta=0.06)
        self.assertLess(mid, trop)
        self.assertGreater(mid, 0.5)

    def test_freezing_level_is_hemisphere_symmetric(self):
        import mw_surface as ms
        self.assertAlmostEqual(float(ms.ice_depth_factor(np.array(-30.0))),
                               float(ms.ice_depth_factor(np.array(30.0))), places=9)

    def test_poleward_storm_is_less_depressed(self):
        from data_types import BandImage, StormFix
        from synthetic_algorithm import generate_synthetic_mw
        t = datetime(2022, 9, 2, 16, tzinfo=timezone.utc)

        def run(clat):
            n = 110
            lat, lon = np.mgrid[clat + 6:clat - 6:n * 1j, -162:-144:n * 1j]
            d = np.sqrt((lat - clat) ** 2
                        + ((lon + 153.0) * np.cos(np.radians(clat))) ** 2) * 111.32
            ir = np.where(d < 20, 282.0,
                          300.0 - 110.0 * np.exp(-0.5 * (d / 110.0) ** 2))
            mk = lambda v, b: BandImage(band=b, satellite="GOES-18", scene_time=t,
                                        values=v, lat=lat, lon=lon, units="K",
                                        mesoscale_sector="M1")
            fx = StormFix(storm_id="X", valid_time=t, lat=clat, lon=-153.0,
                          vmax_kt=110.0, mslp_mb=950.0, rmw_nm=19.0, roci_nm=240.0)
            r = generate_synthetic_mw(mk(ir, 13), mk(ir + 3, 9), mk(ir + 6, 7), fx,
                                      real_swath=None)
            return float(np.nanmedian(r.h89[d < 40]))

        self.assertGreater(run(32.0), run(12.0) + 5.0,
                           "freezing-level scaling has no effect with latitude")


class TestAtmosphericAnomaly(unittest.TestCase):
    """The background constants carried a MEAN atmospheric contribution
    (~25 K at 37H) folded into a fixed number, so it could not vary with
    the moisture field. That is a systematic, spatially-varying error
    hiding in a constant -- and it matches the symptom exactly: bias was
    76% of the error budget and did not move between 298 and 799 training
    examples. More data cannot learn something the input never varies
    with."""

    def test_zero_at_the_tropical_mean(self):
        """Must reproduce the existing constants for a typical column, or
        it double-counts what they already contain."""
        import mw_surface as ms
        mid = 0.5 * (ms.WV_DRY_K + ms.WV_MOIST_K)
        for f in (37, 89):
            for p in ("v", "h"):
                self.assertAlmostEqual(
                    float(ms.atmospheric_anomaly_k(np.array(mid), f, p)), 0.0, places=6)

    def test_moist_is_warmer_than_dry(self):
        import mw_surface as ms
        dry = float(ms.atmospheric_anomaly_k(np.array(ms.WV_DRY_K), 37, "h"))
        moist = float(ms.atmospheric_anomaly_k(np.array(ms.WV_MOIST_K), 37, "h"))
        self.assertLess(dry, 0.0)
        self.assertGreater(moist, 0.0)

    def test_h_pol_moves_more_than_v_pol(self):
        """Over ocean the surface reflects downwelling atmospheric
        radiation, and H-pol reflects far more of it."""
        import mw_surface as ms
        h = abs(float(ms.atmospheric_anomaly_k(np.array(ms.WV_MOIST_K), 37, "h")))
        v = abs(float(ms.atmospheric_anomaly_k(np.array(ms.WV_MOIST_K), 37, "v")))
        self.assertGreater(h, 1.5 * v)

    def test_suppressed_over_land(self):
        import mw_surface as ms
        a = ms.atmospheric_anomaly_k(np.array(ms.WV_MOIST_K), 37, "h",
                                     land_fraction=np.array(1.0))
        self.assertAlmostEqual(float(a), 0.0, places=6)

    def test_saturates_outside_the_range(self):
        """An extreme WV value must not extrapolate to an absurd shift."""
        import mw_surface as ms
        for wv in (400.0, 100.0):
            a = abs(float(ms.atmospheric_anomaly_k(np.array(wv), 37, "h")))
            self.assertLessEqual(a, ms.ATMOS_SWING_K[37]["h"] / 2 + 1e-6)

    def test_background_responds_in_a_full_frame(self):
        from data_types import BandImage, StormFix
        from synthetic_algorithm import generate_synthetic_mw
        t = datetime(2022, 9, 2, 16, tzinfo=timezone.utc)
        n = 110
        lat, lon = np.mgrid[20:8:n * 1j, -162:-144:n * 1j]
        d = np.sqrt((lat - 14.0) ** 2
                    + ((lon + 153.0) * np.cos(np.radians(14.0))) ** 2) * 111.32
        ir = np.where(d < 20, 282.0, 300.0 - 110.0 * np.exp(-0.5 * (d / 110.0) ** 2))
        mk = lambda v, b: BandImage(band=b, satellite="GOES-18", scene_time=t,
                                    values=v, lat=lat, lon=lon, units="K",
                                    mesoscale_sector="M1")
        fx = StormFix(storm_id="X", valid_time=t, lat=14.0, lon=-153.0,
                      vmax_kt=110.0, mslp_mb=950.0, rmw_nm=19.0, roci_nm=240.0)
        far = d > 500
        vals = []
        for wv in (252.0, 224.0):
            r = generate_synthetic_mw(mk(ir, 13), mk(np.full_like(ir, wv), 9),
                                      mk(ir + 6, 7), fx, real_swath=None)
            vals.append(float(np.nanmedian(r.h37[far])))
        self.assertGreater(vals[1] - vals[0], 10.0,
                           "far-field background does not respond to moisture")


class TestPhysicalConsistency(unittest.TestCase):
    """Sensitivity checks in the spirit of Li et al. (2026), who validate
    their model by perturbing the input and confirming the output responds
    the way the physics requires -- removing outer rainbands and checking
    the concentric eyewall disappears.

    These are cheap, need no data, and catch the failure mode that unit
    tests miss entirely: a physics change that runs clean, produces
    plausible-looking output, and is wrong. Every one of them held when
    written; a future change that breaks one has broken something real.
    """

    def _gen(self, vmax=110.0, rmw_nm=19.0, depth=1.0, n=200):
        from data_types import BandImage, StormFix
        from synthetic_algorithm import generate_synthetic_mw
        t = datetime(2022, 9, 2, 16, tzinfo=timezone.utc)
        lat, lon = np.mgrid[20:8:n * 1j, -162:-144:n * 1j]
        d = np.sqrt((lat - 14.0) ** 2
                    + ((lon + 153.0) * np.cos(np.radians(14.0))) ** 2) * 111.32
        rmw = rmw_nm * 1.852
        ir = np.where(d < 0.7 * rmw, 288.0,
                      300.0 - depth * (60.0 + 0.6 * vmax)
                      * np.exp(-0.5 * (d / (2.6 * rmw + 60.0)) ** 2))
        mk = lambda v, b: BandImage(band=b, satellite="GOES-18", scene_time=t,
                                    values=v, lat=lat, lon=lon, units="K",
                                    mesoscale_sector="M1")
        fx = StormFix(storm_id="X", valid_time=t, lat=14.0, lon=-153.0,
                      vmax_kt=vmax, mslp_mb=950.0, rmw_nm=rmw_nm, roci_nm=240.0)
        return generate_synthetic_mw(mk(ir, 13), mk(ir + 3, 9), mk(ir + 6, 7),
                                     fx, real_swath=None), d

    def test_89_response_is_a_hook_not_a_ramp(self):
        """REPLACES a strict-monotonicity assertion, and the replacement is
        the point rather than a concession.

        The old test demanded 89 GHz get monotonically colder with depth.
        That was only true because the backbone had NO emission term at
        89 GHz -- it was pure scattering, a ramp. Real 89 GHz over ocean
        is non-monotonic: cloud and rain liquid emit and raise Tb slightly
        before ice scattering takes over and drops it hard.

        So the assertion is now the real shape. Deep convection must be
        far colder than background, and the deepest colder than moderate;
        a small warm bump at shallow depth is correct and no longer fails.

        The magnitude is bounded too: the real Norbert 89H frame shows the
        ocean background near 280 K with EVERY convective feature colder,
        so the emission term must be weak."""
        mins = [float(np.nanmin(self._gen(depth=x)[0].v89))
                for x in (0.0, 0.3, 0.7, 1.0)]
        background, shallow, moderate, deepest = mins
        self.assertLess(deepest, moderate,
                        f"deepest convection is not the coldest: {mins}")
        self.assertLess(deepest, background - 60.0,
                        f"deep convection barely depressed: {mins}")
        # The warm bump is real but must stay small -- an emitting layer
        # cannot exceed the surface physical temperature.
        self.assertLess(max(mins) - background, 5.0,
                        f"89 GHz emission bump is implausibly large: {mins}")

    def test_89_emission_cannot_exceed_the_physical_temperature(self):
        from synthetic_algorithm import CALIBRATION as C
        for pol in ("v", "h"):
            peak = C[f"bg_{pol}_89"] + C[f"emission_boost_{pol}89"] + 8.0
            self.assertLess(peak, 300.0,
                            f"89{pol.upper()} emission peaks at {peak:.0f} K, at or "
                            f"above the sea-surface physical temperature")

    def test_no_cold_cloud_gives_no_signature(self):
        """A scene with no convection must not manufacture an eyewall."""
        r, d = self._gen(depth=0.0)
        core = float(np.nanmedian(r.v89[d < 60]))
        far = float(np.nanmedian(r.v89[d > 600]))
        self.assertLess(abs(core - far), 25.0,
                        "invented a core signature from a convection-free scene")

    def test_stronger_storm_roughens_the_surface_more(self):
        vals = [float(np.nanmedian(self._gen(vmax=v)[0].h37[
            (self._gen(vmax=v)[1] > 150) & (self._gen(vmax=v)[1] < 250)]))
            for v in (35.0, 90.0, 140.0)]
        self.assertTrue(all(np.diff(vals) > 0), f"not monotonic: {vals}")

    def test_larger_rmw_gives_larger_eyewall(self):
        ew = []
        for rmw in (12.0, 25.0, 45.0):
            r, _ = self._gen(rmw_nm=rmw)
            ew.append(r.diagnostics["structure"]["corrected_89"]["eyewall_radius_km"] or 0.0)
        self.assertTrue(all(np.diff(ew) > 0), f"not monotonic: {ew}")

    def test_89_is_always_sharper_than_37(self):
        """Real 89 GHz resolves finer structure than 37 GHz. Before 0.112
        these fields were bit-identical in structure."""
        r, _ = self._gen()
        g37 = float(np.hypot(*np.gradient(r.v37)).mean())
        g89 = float(np.hypot(*np.gradient(r.v89)).mean())
        self.assertGreater(g89, g37)

    def test_output_stays_physical_across_the_intensity_range(self):
        for vmax, rmw in ((35.0, 60.0), (90.0, 25.0), (140.0, 12.0)):
            r, _ = self._gen(vmax=vmax, rmw_nm=rmw)
            for name in ("v37", "h37", "v89", "h89"):
                a = getattr(r, name)
                self.assertTrue(np.all(np.isfinite(a)), f"{name} non-finite at {vmax}kt")
                self.assertGreater(float(np.nanmin(a)), 50.0, f"{name} too cold at {vmax}kt")
                self.assertLess(float(np.nanmax(a)), 350.0, f"{name} too warm at {vmax}kt")


class TestNoUnboundLocals(unittest.TestCase):
    """Catch `x = f(x)` where x is neither a parameter nor previously
    assigned -- guaranteed UnboundLocalError the moment the function runs.

    This exact bug shipped in `goes_fetch.download_and_open`, which gained
    a stray `target_time = _as_utc(target_time)` from a sloppy scripted
    edit. Nothing caught it: the function only runs against the network,
    so the preflight could not reach it and the unit tests never call it.
    It failed 169 mining attempts before fail-fast stopped the run.

    A static check costs nothing and covers every function, including the
    ones that need S3 to execute.
    """

    def _offenders_in(self, path):
        import ast as _ast
        with open(path, encoding="utf-8") as fh:
            tree = _ast.parse(fh.read(), filename=path)
        bad = []
        for fn in [n for n in _ast.walk(tree)
                   if isinstance(n, (_ast.FunctionDef, _ast.AsyncFunctionDef))]:
            args = fn.args
            params = {a.arg for a in
                      list(args.posonlyargs) + list(args.args) + list(args.kwonlyargs)}
            if args.vararg:
                params.add(args.vararg.arg)
            if args.kwarg:
                params.add(args.kwarg.arg)
            assigned = set(params)
            for node in _ast.walk(fn):
                # Names bound by any construct count as assigned.
                if isinstance(node, _ast.Assign):
                    for t in node.targets:
                        for nm in _ast.walk(t):
                            if isinstance(nm, _ast.Name):
                                assigned.add(nm.id)
                elif isinstance(node, (_ast.For, _ast.comprehension)):
                    tgt = node.target
                    for nm in _ast.walk(tgt):
                        if isinstance(nm, _ast.Name):
                            assigned.add(nm.id)
                elif isinstance(node, _ast.withitem) and node.optional_vars is not None:
                    for nm in _ast.walk(node.optional_vars):
                        if isinstance(nm, _ast.Name):
                            assigned.add(nm.id)
                elif isinstance(node, (_ast.Import, _ast.ImportFrom)):
                    for al in node.names:
                        assigned.add((al.asname or al.name).split(".")[0])
                elif isinstance(node, _ast.ExceptHandler) and node.name:
                    assigned.add(node.name)
                elif isinstance(node, _ast.Global) or isinstance(node, _ast.Nonlocal):
                    assigned.update(node.names)

            # Now look specifically for `x = <expr using x>` where x is
            # not a parameter and is assigned nowhere earlier in the body.
            seen = set(params)
            for stmt in fn.body:
                if (isinstance(stmt, _ast.Assign) and len(stmt.targets) == 1
                        and isinstance(stmt.targets[0], _ast.Name)):
                    name = stmt.targets[0].id
                    used = {n.id for n in _ast.walk(stmt.value)
                            if isinstance(n, _ast.Name)}
                    if name in used and name not in seen:
                        bad.append(f"{os.path.basename(path)}:{stmt.lineno} "
                                   f"in {fn.name}(): '{name}'")
                    seen.add(name)
                elif isinstance(stmt, _ast.Assign):
                    for t in stmt.targets:
                        for nm in _ast.walk(t):
                            if isinstance(nm, _ast.Name):
                                seen.add(nm.id)
                else:
                    for nm in _ast.walk(stmt):
                        if isinstance(nm, _ast.Name) and isinstance(nm.ctx, _ast.Store):
                            seen.add(nm.id)

        return bad

    def _use_before_def(self, path):
        """Names USED at statement level before they are bound in the same
        function body.

        The self-referential check below only caught `x = f(x)`. It missed
        a nested helper defined AFTER its first call -- which is the same
        UnboundLocalError and shipped in ml_train's loader, passing all
        138 tests. Generalised here.

        Only flags straight-line use within one block, so the legitimate
        pattern of two nested functions calling each other is untouched.
        """
        import ast as _ast
        import builtins
        with open(path, encoding="utf-8") as fh:
            tree = _ast.parse(fh.read(), filename=path)

        # MODULE level only. Walking the whole tree here swept up every
        # NESTED function name too, so a helper defined after its call
        # site looked module-global and the check passed vacuously -- it
        # returned clean on the exact bug it was written for.
        module_names = set(dir(builtins))

        def _collect_module_level(body):
            for node in body:
                if isinstance(node, (_ast.Import, _ast.ImportFrom)):
                    for al in node.names:
                        module_names.add((al.asname or al.name).split(".")[0])
                elif isinstance(node, (_ast.FunctionDef, _ast.AsyncFunctionDef,
                                       _ast.ClassDef)):
                    module_names.add(node.name)
                elif isinstance(node, _ast.Assign):
                    for t in node.targets:
                        for nm in _ast.walk(t):
                            if isinstance(nm, _ast.Name):
                                module_names.add(nm.id)
                elif isinstance(node, _ast.AnnAssign):
                    # `NAME: type = value`. Missing this reported the
                    # annotated module globals in mw_ingest as unbound --
                    # module-level names are resolved at call time, so
                    # source order there is irrelevant.
                    if isinstance(node.target, _ast.Name):
                        module_names.add(node.target.id)
                elif isinstance(node, (_ast.If, _ast.Try)):
                    # module-level conditionals still bind globals
                    _collect_module_level(node.body)
                    _collect_module_level(getattr(node, "orelse", []))
                    for h in getattr(node, "handlers", []):
                        _collect_module_level(h.body)

        _collect_module_level(tree.body)

        # Closures see their enclosing function's names, so seed from the
        # whole scope chain -- without this, a nested helper using an outer
        # variable is reported as unbound.
        enclosing = {}

        def _names_in(fn):
            out = set()
            for nm in _ast.walk(fn):
                if isinstance(nm, _ast.Name) and isinstance(nm.ctx, _ast.Store):
                    out.add(nm.id)
                elif isinstance(nm, (_ast.FunctionDef, _ast.AsyncFunctionDef,
                                     _ast.ClassDef)):
                    out.add(nm.name)
                elif isinstance(nm, _ast.arg):
                    out.add(nm.arg)
                elif isinstance(nm, (_ast.Import, _ast.ImportFrom)):
                    for al in nm.names:
                        out.add((al.asname or al.name).split(".")[0])
            return out

        def _descend(node, inherited):
            for child in _ast.iter_child_nodes(node):
                if isinstance(child, (_ast.FunctionDef, _ast.AsyncFunctionDef)):
                    enclosing[child] = inherited
                    _descend(child, inherited | _names_in(child))
                else:
                    _descend(child, inherited)

        _descend(tree, set(module_names))

        bad = []
        for fn in [n for n in _ast.walk(tree)
                   if isinstance(n, (_ast.FunctionDef, _ast.AsyncFunctionDef))]:
            a = fn.args
            bound = set(enclosing.get(fn, module_names)) | {x.arg for x in
                      list(a.posonlyargs) + list(a.args) + list(a.kwonlyargs)}
            if a.vararg:
                bound.add(a.vararg.arg)
            if a.kwarg:
                bound.add(a.kwarg.arg)
            # ONLY simple statements at the top level of the body.
            #
            # A first version walked every statement subtree and produced
            # dozens of false positives: inside `for x in items:` or
            # `with open(p) as f:` the loop/context variable is bound by
            # the statement itself, and a naive linear pass sees the load
            # first. Compound statements also execute conditionally, so
            # "defined later in the source" does not imply "unbound at
            # runtime".
            #
            # Restricting to straight-line Assign/Expr keeps the check
            # sound. It still catches the case that shipped -- a helper
            # called on one line and defined twenty lines below.
            for stmt in fn.body:
                if isinstance(stmt, (_ast.Assign, _ast.Expr, _ast.Return)):
                    # Comprehension targets bind within the comprehension
                    # itself, ahead of any load in it.
                    local_binds = set()
                    for comp in _ast.walk(stmt):
                        if isinstance(comp, _ast.comprehension):
                            for nm in _ast.walk(comp.target):
                                if isinstance(nm, _ast.Name):
                                    local_binds.add(nm.id)
                        elif isinstance(comp, _ast.Lambda):
                            la = comp.args
                            local_binds |= {x.arg for x in
                                            list(la.posonlyargs) + list(la.args)
                                            + list(la.kwonlyargs)}
                    bound |= local_binds
                    for nm in _ast.walk(stmt):
                        if (isinstance(nm, _ast.Name)
                                and isinstance(nm.ctx, _ast.Load)
                                and nm.id not in bound):
                            bad.append(f"{os.path.basename(path)}:{nm.lineno} "
                                       f"in {fn.name}(): '{nm.id}' used before "
                                       f"assignment")
                            bound.add(nm.id)
                # Bind whatever this statement introduces, whatever its kind.
                for nm in _ast.walk(stmt):
                    if isinstance(nm, _ast.Name) and isinstance(nm.ctx, _ast.Store):
                        bound.add(nm.id)
                    elif isinstance(nm, (_ast.FunctionDef, _ast.AsyncFunctionDef,
                                         _ast.ClassDef)):
                        bound.add(nm.name)
                    elif isinstance(nm, (_ast.Import, _ast.ImportFrom)):
                        for al in nm.names:
                            bound.add((al.asname or al.name).split(".")[0])
                    elif isinstance(nm, _ast.ExceptHandler) and nm.name:
                        bound.add(nm.name)
                    elif isinstance(nm, _ast.arg):
                        bound.add(nm.arg)
        return bad

    def test_no_use_before_definition(self):
        import glob as _glob
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        offenders = []
        for path in _glob.glob(os.path.join(src_dir, "**", "*.py"), recursive=True):
            offenders.extend(self._use_before_def(path))
        self.assertEqual(offenders, [],
                         "used before assignment: " + "; ".join(offenders[:8]))

    def test_no_self_referential_first_assignment(self):
        import glob as _glob
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        offenders = []
        for path in _glob.glob(os.path.join(src_dir, "**", "*.py"), recursive=True):
            offenders.extend(self._offenders_in(path))
        self.assertEqual(offenders, [],
                         "name used in its own first assignment (UnboundLocalError): "
                         + "; ".join(offenders))


class TestNoHardcodedPosixPaths(unittest.TestCase):
    """A hardcoded "/tmp/..." default produced
    `PermissionError: [WinError 5] Access is denied` on Windows. It showed
    up once in 4,867 attempts only because it needs the download path
    rather than the cached one -- on a clean machine it fails every time.
    """

    def test_no_tmp_defaults_in_signatures(self):
        import glob as _glob
        import re as _re
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        offenders = []
        for path in _glob.glob(os.path.join(src_dir, "**", "*.py"), recursive=True):
            with open(path, encoding="utf-8") as fh:
                for i, line in enumerate(fh, 1):
                    st = line.strip()
                    if st.startswith("#") or '"""' in st:
                        continue
                    # a POSIX absolute path used as a default value
                    if _re.search(r'=\s*["\']/(tmp|var|home)/', line):
                        offenders.append(f"{os.path.basename(path)}:{i}")
        self.assertEqual(offenders, [],
                         f"hardcoded POSIX path default (breaks on Windows): {offenders}")

    def test_cache_dir_is_platform_correct(self):
        import tempfile
        import goes_fetch as gf
        self.assertTrue(gf._default_cache_dir().startswith(tempfile.gettempdir()))


class TestFixedGridGeolocation(unittest.TestCase):
    """ABI products are on a fixed grid in SCAN ANGLE, not lat/lon. This
    projection is what makes full-disk files usable: mining only ever read
    the steerable mesoscale sectors, losing 83% of storm-times (4,023 of
    4,867) to 'no covering sector'."""

    SAT = -75.2

    def test_subsatellite_point_is_the_origin(self):
        import goes_fixed_grid as g
        x, y, v = g.lat_lon_to_scan_angles(0.0, self.SAT, self.SAT)
        self.assertAlmostEqual(float(x), 0.0, places=12)
        self.assertAlmostEqual(float(y), 0.0, places=12)
        self.assertTrue(bool(v))

    def test_round_trip_is_exact(self):
        """Forward and inverse must agree to far better than a pixel --
        2 km is 1.8e-2 degrees, and any systematic error here silently
        mislocates every crop."""
        import goes_fixed_grid as g
        for lat, lon, sat in [(0.0, -75.2, -75.2), (25.0, -60.0, -75.2),
                              (13.5, -153.0, -137.0), (29.0, -94.0, -75.2),
                              (-20.0, -60.0, -75.2), (45.0, -120.0, -137.0)]:
            x, y, v = g.lat_lon_to_scan_angles(lat, lon, sat)
            self.assertTrue(bool(v), f"({lat},{lon}) should be visible from {sat}")
            la, lo, ok = g.scan_angles_to_lat_lon(x, y, sat)
            self.assertTrue(bool(ok))
            self.assertAlmostEqual(float(la), lat, places=8)
            self.assertAlmostEqual(float(lo), lon, places=8)

    def test_beyond_the_limb_is_rejected(self):
        """The geometry still returns numbers past the limb, and they are
        meaningless -- the mask has to be honoured, not assumed."""
        import goes_fixed_grid as g
        for lat, lon in [(0.0, 105.0), (0.0, 19.8), (0.0, 60.0)]:
            _, _, v = g.lat_lon_to_scan_angles(lat, lon, self.SAT)
            self.assertFalse(bool(v), f"({lat},{lon}) should be beyond the limb")

    def _disk(self):
        n, half = 5424, 0.151872
        return np.linspace(-half, half, n), np.linspace(half, -half, n), n

    def test_crop_contains_the_storm_and_is_small(self):
        import goes_fixed_grid as g
        xs, ys, n = self._disk()
        b = g.crop_bounds(xs, ys, 25.0, -60.0, self.SAT, half_width_km=512.0)
        self.assertIsNotNone(b)
        lat, lon = g.crop_lat_lon(xs, ys, b, self.SAT)
        self.assertLess(float(np.nanmin(lat)), 25.0)
        self.assertGreater(float(np.nanmax(lat)), 25.0)
        self.assertLess(float(np.nanmin(lon)), -60.0)
        self.assertGreater(float(np.nanmax(lon)), -60.0)
        # The whole point: a crop must be a tiny fraction of the disk, or
        # ranged reads buy nothing and full disk stays unaffordable.
        self.assertLess(g.estimate_crop_fraction(b, n, n), 0.02)

    def test_y_axis_descending_is_handled(self):
        """The y axis runs north-to-south. Getting that backwards yields
        an EMPTY slice rather than an error, so it is asserted."""
        import goes_fixed_grid as g
        xs, ys, n = self._disk()
        y0, y1, x0, x1 = g.crop_bounds(xs, ys, 25.0, -60.0, self.SAT)
        self.assertGreater(y1, y0)
        self.assertGreater(x1, x0)
        # A northern storm must sit at a SMALLER row index than a southern one.
        north = g.crop_bounds(xs, ys, 35.0, -60.0, self.SAT)[0]
        south = g.crop_bounds(xs, ys, 10.0, -60.0, self.SAT)[0]
        self.assertLess(north, south)

    def test_off_disk_storm_returns_none(self):
        import goes_fixed_grid as g
        xs, ys, n = self._disk()
        self.assertIsNone(g.crop_bounds(xs, ys, 15.0, 150.0, self.SAT))


class TestCroppedRead(unittest.TestCase):
    """Exercises the full-disk read path against a fake that models the
    real ABI file format -- scaled int16 coordinates with a CENTRED
    add_offset, scaled radiance with a fill sentinel.

    The fake matters as much as the test. A first version scaled x/y into
    0..65534 and stored them as int16, which overflows at 32767; the
    reader correctly returned None and the FIXTURE was wrong. Mocks that
    do not model the format faithfully test the wrong thing -- the same
    lesson as the boto3 mock that made Range mandatory.
    """

    SAT = -75.2
    N = 600

    def _fake_file(self):
        import goes_fixed_grid as g

        class FakeDS:
            def __init__(self, a, attrs=None):
                self._a = np.asarray(a)
                self.attrs = attrs or {}

            def __getitem__(self, k):
                return self._a[k]

            @property
            def shape(self):
                return self._a.shape

        class FakeH5(dict):
            def keys(self):
                return dict.keys(self)

        def scaled_int16(vals):
            sc = (vals[-1] - vals[0]) / 65534.0
            off = vals[0] + 32767.0 * sc
            return np.round((vals - off) / sc).astype(np.int16), sc, off

        n, half = self.N, 0.151872
        xs = np.linspace(-half, half, n)
        ys = np.linspace(half, -half, n)
        xr, xsc, xoff = scaled_int16(xs)
        yr, ysc, yoff = scaled_int16(ys)
        xg, yg = np.meshgrid(xs, ys)
        lat, lon, valid = g.scan_angles_to_lat_lon(xg, yg, self.SAT)
        d = np.where(valid, np.sqrt((lat - 25.0) ** 2
                     + ((lon + 60.0) * np.cos(np.radians(25.0))) ** 2) * 111.32, np.nan)
        rad_true = 120.0 - 70.0 * np.exp(-0.5 * (d / 150.0) ** 2)
        rsc, roff, fill = 0.01, 0.0, -1
        raw = np.where(np.isfinite(rad_true),
                       np.round((rad_true - roff) / rsc), fill).astype(np.int32)
        h5 = FakeH5({
            "x": FakeDS(xr, {"scale_factor": xsc, "add_offset": xoff}),
            "y": FakeDS(yr, {"scale_factor": ysc, "add_offset": yoff}),
            "Rad": FakeDS(raw, {"scale_factor": rsc, "add_offset": roff,
                                "_FillValue": fill}),
            "DQF": FakeDS(np.zeros((n, n), np.int8)),
            "planck_fk1": FakeDS(np.array(2.0e5)),
            "planck_fk2": FakeDS(np.array(1.4e3)),
            "planck_bc1": FakeDS(np.array(0.5)),
            "planck_bc2": FakeDS(np.array(0.9995)),
        })
        return h5, rad_true

    def test_crop_is_a_small_fraction_of_the_disk(self):
        import goes_fixed_grid as g
        h5, _ = self._fake_file()
        out = g.read_cropped_radiance(h5, 25.0, -60.0, self.SAT, half_width_km=512.0)
        self.assertIsNotNone(out)
        self.assertLess(out[4]["crop_fraction"], 0.02)

    def test_descaling_is_correct(self):
        """Coordinates and radiance are stored as scaled integers.
        Forgetting scale_factor gives an EMPTY crop, not an error."""
        import goes_fixed_grid as g
        h5, rad_true = self._fake_file()
        rad, _, _, _, meta = g.read_cropped_radiance(h5, 25.0, -60.0, self.SAT)
        y0, y1, x0, x1 = meta["bounds"]
        err = float(np.nanmax(np.abs(rad - rad_true[y0:y1, x0:x1])))
        self.assertLess(err, 0.01)     # within one quantum

    def test_crop_is_centred_on_the_storm(self):
        import goes_fixed_grid as g
        h5, _ = self._fake_file()
        rad, _, lat, lon, _ = g.read_cropped_radiance(h5, 25.0, -60.0, self.SAT)
        cy, cx = lat.shape[0] // 2, lat.shape[1] // 2
        self.assertAlmostEqual(float(lat[cy, cx]), 25.0, delta=0.5)
        self.assertAlmostEqual(float(lon[cy, cx]), -60.0, delta=0.5)

    def test_brightness_temperature_peaks_at_the_storm(self):
        import goes_fixed_grid as g
        h5, _ = self._fake_file()
        rad, _, lat, lon, meta = g.read_cropped_radiance(h5, 25.0, -60.0, self.SAT)
        tb = g.radiance_to_brightness_temperature(rad, meta["planck"])
        self.assertIsNotNone(tb)
        cold = np.unravel_index(np.nanargmin(tb), tb.shape)
        self.assertAlmostEqual(float(lat[cold]), 25.0, delta=1.0)
        self.assertAlmostEqual(float(lon[cold]), -60.0, delta=1.0)

    def test_non_positive_radiance_becomes_nan_not_inf(self):
        import goes_fixed_grid as g
        planck = {"planck_fk1": 2.0e5, "planck_fk2": 1.4e3,
                  "planck_bc1": 0.5, "planck_bc2": 0.9995}
        tb = g.radiance_to_brightness_temperature(
            np.array([-5.0, 0.0, 50.0]), planck)
        self.assertTrue(np.isnan(tb[0]) and np.isnan(tb[1]))
        self.assertTrue(np.isfinite(tb[2]))

    def test_off_disk_storm_returns_none(self):
        import goes_fixed_grid as g
        h5, _ = self._fake_file()
        self.assertIsNone(g.read_cropped_radiance(h5, 15.0, 150.0, self.SAT))


class TestNoUndefinedNames(unittest.TestCase):
    """Catch calls to names that exist in no scope -- guaranteed
    NameError as soon as that branch runs.

    `get_band_image_any_sector` called `format_bytes()`, which lives in
    tcprimed_ingest and is not imported into goes_fetch. Worse than a
    plain crash: the call sat BEFORE the return, so every full-disk crop
    was fetched, decoded, and then thrown away by a NameError in a
    progress message. The log said "full-disk fallback failed" and the
    work was already done.

    Only checks CALLED names, which keeps false positives near zero while
    covering the case that actually bites.
    """

    def _undefined_calls(self, path):
        import ast as _ast
        import builtins
        with open(path, encoding="utf-8") as fh:
            tree = _ast.parse(fh.read(), filename=path)

        module_names = set(dir(builtins))
        for node in _ast.walk(tree):
            if isinstance(node, (_ast.Import, _ast.ImportFrom)):
                for al in node.names:
                    module_names.add((al.asname or al.name).split(".")[0])
            elif isinstance(node, (_ast.FunctionDef, _ast.AsyncFunctionDef, _ast.ClassDef)):
                module_names.add(node.name)
            elif isinstance(node, _ast.Assign):
                for t in node.targets:
                    for nm in _ast.walk(t):
                        if isinstance(nm, _ast.Name):
                            module_names.add(nm.id)

        bad = []

        def _bound_in(fn):
            """Names bound anywhere inside this function."""
            out = set()
            a = fn.args
            out |= {x.arg for x in
                    list(a.posonlyargs) + list(a.args) + list(a.kwonlyargs)}
            if a.vararg:
                out.add(a.vararg.arg)
            if a.kwarg:
                out.add(a.kwarg.arg)
            for node in _ast.walk(fn):
                if isinstance(node, _ast.Name) and isinstance(node.ctx, _ast.Store):
                    out.add(node.id)
                elif isinstance(node, (_ast.Import, _ast.ImportFrom)):
                    for al in node.names:
                        out.add((al.asname or al.name).split(".")[0])
                elif isinstance(node, _ast.ExceptHandler) and node.name:
                    out.add(node.name)
                elif isinstance(node, _ast.arg):
                    out.add(node.arg)
                elif isinstance(node, (_ast.FunctionDef, _ast.AsyncFunctionDef,
                                       _ast.ClassDef)):
                    out.add(node.name)
                elif isinstance(node, _ast.comprehension):
                    for nm in _ast.walk(node.target):
                        if isinstance(nm, _ast.Name):
                            out.add(nm.id)
            return out

        # Closures see their ENCLOSING function's names. Walking functions
        # flat reported four false positives on nested helpers that use a
        # progress_callback belonging to the outer scope -- and one REAL
        # bug hiding among them, which is why the scope chain matters
        # rather than just relaxing the check.
        enclosing = {}

        def _descend(node, inherited):
            for child in _ast.iter_child_nodes(node):
                if isinstance(child, (_ast.FunctionDef, _ast.AsyncFunctionDef)):
                    enclosing[child] = inherited
                    _descend(child, inherited | _bound_in(child))
                else:
                    _descend(child, inherited)

        _descend(tree, set(module_names))

        for fn in [n for n in _ast.walk(tree)
                   if isinstance(n, (_ast.FunctionDef, _ast.AsyncFunctionDef))]:
            local = set(enclosing.get(fn, module_names))
            a = fn.args
            local |= {x.arg for x in
                      list(a.posonlyargs) + list(a.args) + list(a.kwonlyargs)}
            if a.vararg:
                local.add(a.vararg.arg)
            if a.kwarg:
                local.add(a.kwarg.arg)
            for node in _ast.walk(fn):
                if isinstance(node, _ast.Name) and isinstance(node.ctx, _ast.Store):
                    local.add(node.id)
                elif isinstance(node, (_ast.Import, _ast.ImportFrom)):
                    for al in node.names:
                        local.add((al.asname or al.name).split(".")[0])
                elif isinstance(node, _ast.ExceptHandler) and node.name:
                    local.add(node.name)
                elif isinstance(node, _ast.arg):
                    local.add(node.arg)
                elif isinstance(node, (_ast.FunctionDef, _ast.AsyncFunctionDef,
                                       _ast.ClassDef)):
                    local.add(node.name)
                elif isinstance(node, _ast.comprehension):
                    for nm in _ast.walk(node.target):
                        if isinstance(nm, _ast.Name):
                            local.add(nm.id)
            for node in _ast.walk(fn):
                if (isinstance(node, _ast.Call) and isinstance(node.func, _ast.Name)
                        and node.func.id not in local):
                    bad.append(f"{os.path.basename(path)}:{node.lineno} "
                               f"in {fn.name}(): {node.func.id}()")
        return bad

    def test_no_calls_to_undefined_names(self):
        import glob as _glob
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        offenders = []
        for path in _glob.glob(os.path.join(src_dir, "**", "*.py"), recursive=True):
            offenders.extend(self._undefined_calls(path))
        self.assertEqual(offenders, [],
                         "call to a name defined in no scope: " + "; ".join(offenders))


class TestRangedIntent(unittest.TestCase):
    """Two optimizations can contradict each other. 0.121 made objects
    under 64 MB fetch whole (right for TC PRIMED, which reads ~93% of a
    small file). 0.124 added full-disk crops reading under 1% of a ~30 MB
    object -- also under the threshold, so the whole file came down and
    the crop saved nothing. The log said it plainly:
    "0.64% of the array, 30.1 MB fetched".

    Size alone cannot decide this; only the caller knows how much it
    intends to read.
    """

    def _reader(self, size, prefer_ranged):
        import io as _io
        import s3_range_reader as srr
        data = np.random.default_rng(0).bytes(size)

        class MockS3:
            def head_object(self, Bucket, Key):
                return {"ContentLength": len(data)}

            def get_object(self, Bucket, Key, Range=None):
                if Range is None:
                    return {"Body": _io.BytesIO(data)}
                a, b = Range.split("=")[1].split("-")
                return {"Body": _io.BytesIO(data[int(a):int(b) + 1])}

        return srr.S3RangeReader(MockS3(), "b", "k", prefer_ranged=prefer_ranged)

    def test_intent_overrides_the_size_rule(self):
        size = 30 * 1024 * 1024          # a full-disk band: under the threshold
        r = self._reader(size, prefer_ranged=True)
        r.seek(size // 2)
        r.read(200_000)
        st = r.stats()
        self.assertEqual(st["mode"], "ranged")
        self.assertLess(st["fetched_fraction"], 0.1,
                        "prefer_ranged did not prevent the whole-object fetch")

    def test_default_still_fetches_small_objects_whole(self):
        r = self._reader(16 * 1024 * 1024, prefer_ranged=False)
        r.seek(1000)
        r.read(1000)
        self.assertEqual(r.stats()["mode"], "whole")

    def test_full_disk_path_asks_for_ranged(self):
        import inspect
        import goes_fetch as gf
        src = inspect.getsource(gf.get_band_image_any_sector)
        self.assertIn("prefer_ranged=True", src,
                      "the full-disk crop must opt out of the whole-object "
                      "shortcut, or it downloads the entire band")


class TestMiningPassesAllInputs(unittest.TestCase):
    """Mining called generate_synthetic_mw WITHOUT extra_ir, so all seven
    supplementary IR channels were neutral in every training example --
    the multi-channel work from 0.98/0.99 never reached the data, and Li
    et al. found that ablation to be their single largest gain. The bands
    were being fetched on the GUI path only, so the code LOOKED wired.

    A channel that is silently constant costs capacity and teaches the
    model to ignore it. Checked structurally because mining needs S3 to
    run.
    """

    def _mining_src(self):
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        with open(os.path.join(src_dir, "ml_data_mining.py"), encoding="utf-8") as fh:
            return fh.read()

    def test_mining_fetches_the_extra_ir_bands(self):
        """Checks the PROPERTY, not a function name. The original pinned
        `fetch_extra_ir_bands`, so merging the base and supplementary
        fetches into one pool -- a pure speed change -- failed a test that
        was asserting which helper was called rather than that the bands
        arrive at all."""
        src = self._mining_src()
        self.assertTrue(
            "fetch_frame_bands" in src or "fetch_extra_ir_bands" in src,
            "mining never fetches the supplementary IR bands")
        self.assertIn("extra_ir=extra_ir", src,
                      "extra bands are fetched but not passed to generate")

    def test_every_generate_call_passes_them(self):
        import re
        src = self._mining_src()
        calls = re.findall(r"generate_synthetic_mw\((?:[^()]|\([^()]*\))*\)", src,
                           re.S)
        self.assertTrue(calls, "no generate_synthetic_mw call found")
        for c in calls:
            self.assertIn("extra_ir", c, "a generate call omits extra_ir")
            self.assertIn("flash_density", c, "a generate call omits flash_density")

    def test_glm_reader_exists(self):
        """glm_lightning degrades to zeros when this is missing, so its
        absence is invisible at runtime -- the channel just stays flat."""
        import goes_fetch as gf
        self.assertTrue(hasattr(gf, "get_glm_flashes"))


class TestConstantsWriter(unittest.TestCase):
    """Rewriting CALIBRATION in source is the riskiest thing this project
    does automatically, so it is pinned: surgical, reversible, and it
    bumps the physics id because the backbone has moved."""

    def _copy_module(self):
        import shutil
        import tempfile
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        d = tempfile.mkdtemp()
        p = os.path.join(d, "synthetic_algorithm.py")
        shutil.copy2(os.path.join(src_dir, "synthetic_algorithm.py"), p)
        return p

    def test_writes_only_the_named_constants(self):
        import ast as _ast
        import calibrate_constants as cc
        import re
        p = self._copy_module()
        out = cc.apply_fitted_constants(
            {"fitted": {"bg_h_37": 176.3, "max_depression_v89": 97.2}},
            module_path=p)
        after = open(p, encoding="utf-8").read()
        self.assertEqual(out["skipped"], [])
        self.assertEqual(float(re.search(r'"bg_h_37"\s*:\s*([\d.]+)', after).group(1)),
                         176.3)
        # an untouched constant must be exactly as it was
        self.assertIsNotNone(re.search(r'"bg_v_37"\s*:\s*250', after))
        _ast.parse(after)          # still valid Python

    def test_changing_a_constant_changes_the_physics_id(self):
        """The id is DERIVED from the constants since 0.136, so it can no
        longer go stale -- and it no longer appears in the file as a
        literal, which is what this test used to assert.

        The property that matters is that editing any physics constant
        produces a different id, so a dataset built before the edit is
        refused afterwards. 0.128 changed the backbone and forgot to bump
        a hand-written string; 0.135 did it again with SATURATION_K.
        Deriving it removes the chance to forget."""
        import synthetic_algorithm as sa
        before = sa._compute_vh_physics_id()
        saved = sa.CALIBRATION["bg_h_37"]
        sa.CALIBRATION["bg_h_37"] = saved + 1.0
        try:
            self.assertNotEqual(sa._compute_vh_physics_id(), before)
        finally:
            sa.CALIBRATION["bg_h_37"] = saved
        self.assertEqual(sa._compute_vh_physics_id(), before)

    def test_id_also_tracks_mw_surface_constants(self):
        """SATURATION_K lives in mw_surface, not CALIBRATION, and moving
        it in 0.135 changed the backbone while the id stayed put."""
        import mw_surface as ms
        import synthetic_algorithm as sa
        before = sa._compute_vh_physics_id()
        saved = ms.SATURATION_K
        ms.SATURATION_K = saved * 2
        try:
            self.assertNotEqual(sa._compute_vh_physics_id(), before)
        finally:
            ms.SATURATION_K = saved

    def test_writes_a_backup(self):
        import calibrate_constants as cc
        p = self._copy_module()
        out = cc.apply_fitted_constants({"fitted": {"bg_h_37": 176.3}}, module_path=p)
        self.assertTrue(os.path.exists(out["backup"]))

    def test_empty_fit_changes_nothing(self):
        import calibrate_constants as cc
        p = self._copy_module()
        before = open(p, encoding="utf-8").read()
        cc.apply_fitted_constants({"fitted": {}}, module_path=p)
        self.assertEqual(open(p, encoding="utf-8").read(), before)


class TestParallelFetches(unittest.TestCase):
    """On a fast link these paths are round-trip bound, not byte bound.
    Fetching three extra bands and ~30 GLM granules serially is ~2 s of
    pure latency per frame for no reason."""

    def _fake_band(self, fail_band=None):
        import types
        def fake(sat, band, t, lat, lon, sector=None, **k):
            if band == fail_band:
                raise RuntimeError("boom")
            return types.SimpleNamespace(band=band, values=np.zeros((4, 4)))
        return fake

    def test_extra_bands_all_returned(self):
        import goes_fetch as gf
        saved = gf.get_band_image_any_sector
        gf.get_band_image_any_sector = self._fake_band()
        try:
            out = gf.fetch_extra_ir_bands(
                "GOES-18", datetime(2022, 9, 2, 16, tzinfo=timezone.utc),
                center_lat=15.0, center_lon=-95.0, limit=3)
        finally:
            gf.get_band_image_any_sector = saved
        self.assertEqual(len(out), 3)
        self.assertTrue(all(isinstance(k, int) for k in out))

    def test_one_failing_band_does_not_lose_the_others(self):
        """Parallel map must not let a single exception drop the batch."""
        import goes_fetch as gf
        saved = gf.get_band_image_any_sector
        gf.get_band_image_any_sector = self._fake_band(fail_band=10)
        try:
            out = gf.fetch_extra_ir_bands(
                "GOES-18", datetime(2022, 9, 2, 16, tzinfo=timezone.utc),
                center_lat=15.0, center_lon=-95.0, limit=3)
        finally:
            gf.get_band_image_any_sector = saved
        self.assertNotIn(10, out)
        self.assertEqual(len(out), 2)

    def test_both_paths_are_threaded(self):
        import inspect
        import goes_fetch as gf
        for fn in (gf.fetch_extra_ir_bands, gf.get_glm_flashes):
            self.assertIn("ThreadPoolExecutor", inspect.getsource(fn),
                          f"{fn.__name__} still fetches serially")


class TestNothingUsefulIsSilentlyInert(unittest.TestCase):
    """Roughly half the real problems in this project were things that
    looked wired and did nothing -- seven dead IR channels, dead uint16
    packing, a checkpoint chosen on a metric correlating -0.41 with
    usefulness. These pin the ones found by an explicit dead-name scan."""

    def test_comparison_summary_is_surfaced(self):
        """compare_both_frequencies ran on every fused frame and only its
        bias_k was consumed; RMSE and pixel counts against real V-pol and
        real PCT were computed and discarded. That is the project's one
        direct quantitative check of synthetic against real."""
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        with open(os.path.join(src_dir, "gui", "main_window.py"), encoding="utf-8") as fh:
            src = fh.read()
        self.assertIn("format_stats_summary", src,
                      "the real-vs-synthetic comparison summary is computed "
                      "and never shown")

    def test_land_mask_backend_is_reported(self):
        """backend_name() existed since 0.97 and was never called, so a run
        could not distinguish an active land mask from the all-ocean
        fallback. Over land that difference is the whole point."""
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        with open(os.path.join(src_dir, "synthetic_algorithm.py"), encoding="utf-8") as fh:
            self.assertIn("backend_name()", fh.read())

    def test_ensemble_constant_is_not_duplicated(self):
        """ml_diffusion.DEFAULT_ENSEMBLE duplicated
        ml_constants.ENSEMBLE_MEMBERS, which is what inference actually
        reads -- so tuning it changed nothing, silently.

        Checked at source level: ml_diffusion imports torch, and this
        suite is deliberately torch-free."""
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        with open(os.path.join(src_dir, "ml_diffusion.py"), encoding="utf-8") as fh:
            src = fh.read()
        self.assertIn("ENSEMBLE_MEMBERS as DEFAULT_ENSEMBLE", src,
                      "DEFAULT_ENSEMBLE is a separate literal again; tuning it "
                      "will silently do nothing")

    def test_no_new_unreferenced_public_names(self):
        """A standing guard, not a one-off. Anything defined here and
        referenced nowhere -- including by tests -- is either dead or a
        capability nobody wired up, and both are worth knowing about."""
        import ast as _ast
        import glob as _glob
        src_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src"))
        files = _glob.glob(os.path.join(src_dir, "**", "*.py"), recursive=True)
        texts = {f: open(f, encoding="utf-8").read() for f in files}
        texts.update({f: open(f, encoding="utf-8").read()
                      for f in _glob.glob(os.path.join(os.path.dirname(__file__), "*.py"))})

        defined = {}
        for f in files:
            for node in _ast.parse(texts[f]).body:
                if isinstance(node, (_ast.FunctionDef, _ast.AsyncFunctionDef)) \
                        and not node.name.startswith("_"):
                    defined.setdefault(node.name, f)

        # Known-dead leftovers, kept deliberately rather than deleted:
        # legacy parsers, retired NEXRAD helpers, and convenience wrappers
        # an external caller may still want.
        allowed = {"nearest_fix", "mine_storm_list", "pct_channel_from_swath",
                   "diagnose_overpass_prediction", "fill_invalid_nearest",
                   "same_instant", "backend_name", "format_stats_summary",
                   "ice_coupling_profile", "apply_fitted_constants",
                   "fetch_bands_parallel", "get_glm_flashes", "preflight",
                   "run_calibration", "estimate_mining", "saturate",
                   "ice_depth_factor", "atmospheric_anomaly_k",
                   "surface_elevation_m", "read_overpass_streaming",
                   "open_overpass_streaming", "fetch_extra_ir_bands",
                   "get_band_image_any_sector", "read_cropped_radiance",
                   "crop_bounds", "crop_lat_lon", "estimate_crop_fraction",
                   "lat_lon_to_scan_angles", "scan_angles_to_lat_lon",
                   "radiance_to_brightness_temperature", "open_s3_hdf5",
                   "normalize_for_model", "flash_density_grid",
                   "sampled_skill", "check_physics_consistency",
                   "pack_tb", "unpack_tb", "as_utc", "as_naive_utc", "utcnow",
                   "normalize_channel", "denormalize_channel"}

        dead = []
        for name, home in defined.items():
            if name in allowed:
                continue
            hits = sum(t.count(name) - (1 if f == home else 0) for f, t in texts.items())
            if hits == 0:
                dead.append(f"{name} ({os.path.basename(home)})")
        self.assertEqual(sorted(dead), [],
                         "defined but referenced nowhere -- dead, or a capability "
                         "nobody wired up: " + "; ".join(sorted(dead)))


class TestEWRC(unittest.TestCase):
    """M-PERC-style secondary-eyewall diagnosis (Kossin et al. 2023).

    Mechanism followed: ring-score profile every 6 km out to 200 km from
    TC center, searched for a SECONDARY MAXIMUM, with KS09's requirement
    that an outer ring close at least 75% of a circle."""

    def _scene(self, rings, closure=1.0, n=220, span=8.0):
        lat, lon = np.mgrid[14 + span / 2:14 - span / 2:n * 1j,
                            -60 - span / 2:-60 + span / 2:n * 1j]
        dy = (lat - 14.0) * 111.32
        dx = (lon + 60.0) * 111.32 * np.cos(np.radians(14.0))
        r = np.sqrt(dx * dx + dy * dy)
        th = np.arctan2(dy, dx)
        tb = np.full((n, n), 285.0)
        for rad, amp, w in rings:
            band = amp * np.exp(-0.5 * ((r - rad) / w) ** 2)
            if closure < 1.0:
                band = np.where((th + np.pi) / (2 * np.pi) < closure, band, 0.0)
            tb -= band
        return tb, lat, lon

    def _conf(self, rings, closure=1.0, vmax=110.0):
        import ewrc
        tb, lat, lon = self._scene(rings, closure)
        return ewrc.ewrc_confidence(tb, lat, lon, 14.0, -60.0, vmax_kt=vmax)

    def test_single_eyewall_is_not_flagged(self):
        r = self._conf([(30, 95, 8)])
        self.assertIsNone(r["secondary_radius_km"])
        self.assertEqual(r["confidence"], 0.0)

    def test_concentric_eyewalls_are_flagged(self):
        r = self._conf([(28, 95, 7), (85, 80, 10)])
        self.assertIsNotNone(r["secondary_radius_km"])
        self.assertGreater(r["secondary_radius_km"], 60.0)
        self.assertGreater(r["confidence"], 0.6)

    def test_primary_lands_on_the_inner_eyewall(self):
        """The profile normalization originally used scene PERCENTILES at
        both ends. An eyewall covers well under 1% of the scene, so the
        cold percentile landed in the background, span collapsed to ~1 K,
        and the profile read flat-topped from 12 to 48 km on a textbook
        30 km ring -- no peak, therefore no primary and no secondary."""
        r = self._conf([(30, 95, 8)])
        self.assertAlmostEqual(r["primary_radius_km"], 30.0, delta=8.0)

    def test_partial_outer_arc_is_rejected(self):
        """KS09 require an outer ring to form at least 75% of a circle."""
        r = self._conf([(28, 95, 7), (85, 80, 10)], closure=0.50)
        self.assertLess(r["confidence"], 0.4)

    def test_nearly_closed_arc_is_accepted(self):
        r = self._conf([(28, 95, 7), (85, 80, 10)], closure=0.85)
        self.assertGreater(r["confidence"], 0.5)

    def test_broad_single_ring_has_no_moat(self):
        """A wide ring is not two rings; without a moat there is no ERC."""
        r = self._conf([(30, 95, 26)])
        self.assertIsNone(r["secondary_radius_km"])

    def test_intensity_baseline_is_reported_separately(self):
        """Kossin et al. display the full model beside a Vmax-only model so
        a forecaster can see whether the cloud presentation says more than
        intensity already did."""
        weak = self._conf([(28, 95, 7), (85, 80, 10)], vmax=45.0)
        strong = self._conf([(28, 95, 7), (85, 80, 10)], vmax=130.0)
        self.assertLess(weak["intensity_baseline"], strong["intensity_baseline"])
        self.assertIn("intensity_baseline", weak)

    def test_runs_only_with_real_microwave(self):
        """IR cannot see through the cirrus canopy -- which is why M-PERC
        uses microwave at all. Running this on the synthetic field would be
        circular, since the backbone derives its response from IR."""
        from data_types import BandImage, StormFix
        from synthetic_algorithm import generate_synthetic_mw
        t = datetime(2022, 9, 2, 16, tzinfo=timezone.utc)
        n = 120
        lat, lon = np.mgrid[18:10:n * 1j, -64:-56:n * 1j]
        d = np.sqrt((lat - 14.0) ** 2
                    + ((lon + 60.0) * np.cos(np.radians(14.0))) ** 2) * 111.32
        ir = np.where(d < 25, 284.0, 300.0 - 110.0 * np.exp(-0.5 * (d / 90.0) ** 2))
        mk = lambda v, b: BandImage(band=b, satellite="GOES-16", scene_time=t,
                                    values=v, lat=lat, lon=lon, units="K",
                                    mesoscale_sector="M1")
        fx = StormFix(storm_id="X", valid_time=t, lat=14.0, lon=-60.0,
                      vmax_kt=115.0, mslp_mb=945.0, rmw_nm=16.0, roci_nm=240.0)
        r = generate_synthetic_mw(mk(ir, 13), mk(ir + 3, 9), mk(ir + 6, 7), fx,
                                  real_swath=None)
        self.assertIsNone(r.diagnostics.get("ewrc"))


class TestWVIR(unittest.TestCase):
    """WV-minus-IR ERC staging (Sanabia et al. 2015).

    Positive WVIR exploits the tropopause inversion to isolate convection
    that has PENETRATED the tropopause -- cirrus and anvil, which sit
    below it, do not produce one. That is why this works from
    geostationary data where plain IR cannot, and why it can fill the
    hours between microwave overpasses."""

    def _frame(self, rings, n=180, span=7.0):
        lat, lon = np.mgrid[14 + span / 2:14 - span / 2:n * 1j,
                            -60 - span / 2:-60 + span / 2:n * 1j]
        dy = (lat - 14.0) * 111.32
        dx = (lon + 60.0) * 111.32 * np.cos(np.radians(14.0))
        r = np.sqrt(dx * dx + dy * dy)
        d = np.zeros_like(r)
        for rad, amp, w in rings:
            d += amp * np.exp(-0.5 * ((r - rad) / w) ** 2)
        ir = np.full((n, n), 235.0)
        return ir + d - 0.3, ir, lat, lon   # background WVIR negative, as in reality

    def _run(self, seq):
        import wvir
        hist, out = [], []
        for rings in seq:
            wv, ir, lat, lon = self._frame(rings)
            r = wvir.analyze(wv, ir, lat, lon, 14.0, -60.0, history=hist)
            hist.append(r)
            out.append(r)
        return out

    def test_full_sinlaku_sequence(self):
        """The six stages as Sanabia et al. describe them for Sinlaku."""
        res = self._run([
            [(60, 3.3, 55)],                    # 1 broad single eyewall
            [(45, 3.1, 26)],                    # 2 outer erosion
            [(30, 2.2, 12), (120, 1.8, 16)],    # 3 concentric
            [(30, 1.5, 12), (120, 1.9, 16)],    # 4 inner decaying
            [(105, 2.0, 18)],                   # 5 inner gone
            [(105, 2.1, 18)],                   # 5 holding
            [(78, 2.4, 16)],                    # 6 contracting
        ])
        self.assertEqual([r["stage"] for r in res], [1, 2, 3, 4, 6, 5, 6])

    def test_narrow_inner_ring_survives_filtering(self):
        """A decaying inner eyewall near 30 km can occupy ONE 6 km bin.
        Detecting peaks on the smoothed profile removed it, and stage 4
        collapsed into stage 5 -- exactly the distinction the paper says
        WVIR resolves before IR does."""
        res = self._run([[(30, 2.2, 12), (120, 1.8, 16)],
                         [(30, 1.5, 12), (120, 1.9, 16)]])
        self.assertEqual(len(res[1]["ring_radii_km"]), 2)
        self.assertEqual(res[1]["stage"], 4)

    def test_negative_wvir_is_excluded(self):
        """Negative difference means the top is BELOW the tropopause and
        carries no deep-convection information; averaging it in would
        dilute the signal with the anvil this measure exists to exclude."""
        import wvir
        wv, ir, lat, lon = self._frame([(60, 3.0, 30)])
        _, prof = wvir.wvir_profile(wv, ir - 50.0, lat, lon, 14.0, -60.0)
        self.assertTrue(np.all(np.asarray(prof) >= 0.0))

    def test_no_convection_is_reported_as_such(self):
        import wvir
        n = 120
        lat, lon = np.mgrid[18:10:n * 1j, -64:-56:n * 1j]
        ir = np.full((n, n), 250.0)
        r = wvir.analyze(ir - 4.0, ir, lat, lon, 14.0, -60.0)
        self.assertIsNone(r["stage"])
        self.assertIn("threshold", " ".join(r["evidence"]))

    def test_change_based_stages_need_history(self):
        """Erosion, decay and contraction are defined by change. Without a
        previous frame they must not be asserted."""
        import wvir
        wv, ir, lat, lon = self._frame([(45, 3.1, 26)])
        r = wvir.analyze(wv, ir, lat, lon, 14.0, -60.0, history=None)
        self.assertEqual(r["stage"], 1)
        self.assertTrue(any("history" in e for e in r["evidence"]))

    def test_reaches_diagnostics_on_goes_only(self):
        """Unlike the microwave EWRC score, this must run WITHOUT a pass."""
        from data_types import BandImage, StormFix
        from synthetic_algorithm import generate_synthetic_mw
        t = datetime(2022, 9, 2, 16, tzinfo=timezone.utc)
        n = 140
        lat, lon = np.mgrid[18:10:n * 1j, -64:-56:n * 1j]
        d = np.sqrt((lat - 14.0) ** 2
                    + ((lon + 60.0) * np.cos(np.radians(14.0))) ** 2) * 111.32
        ir = np.where(d < 25, 284.0, 300.0 - 110.0 * np.exp(-0.5 * (d / 90.0) ** 2))
        wv = ir + 3.0 * np.exp(-0.5 * ((d - 55) / 30) ** 2) - 0.3
        mk = lambda v, b: BandImage(band=b, satellite="GOES-16", scene_time=t,
                                    values=v, lat=lat, lon=lon, units="K",
                                    mesoscale_sector="M1")
        fx = StormFix(storm_id="TEST01", valid_time=t, lat=14.0, lon=-60.0,
                      vmax_kt=110.0, mslp_mb=950.0, rmw_nm=18.0, roci_nm=240.0)
        r = generate_synthetic_mw(mk(ir, 13), mk(wv, 9), mk(ir + 6, 7), fx,
                                  real_swath=None)
        self.assertIsNotNone(r.diagnostics.get("wvir"))
        self.assertIsNone(r.diagnostics.get("ewrc"))   # microwave-only, correctly


class TestEveryReaderUnpacks(unittest.TestCase):
    """0.127 wired in scaled-uint16 storage. Every consumer of a .npz
    must key on dtype, and one did not: calibrate_constants read the
    arrays raw, so a 182 K background came back as 18200 and the
    least-squares fitted constants against values a hundred times too
    large -- no error, just nonsense, which --apply-fit would then write
    straight into CALIBRATION."""

    def _packed_dataset(self):
        import glob as _glob
        import tempfile
        from training_data_export import pack_tb
        from synthetic_algorithm import CALIBRATION as C
        rng = np.random.default_rng(0)
        d = tempfile.mkdtemp()
        for f in range(6):
            n = 40
            A = rng.uniform(0, 1, (n, n))
            B = rng.uniform(0, 1, (n, n)) * A
            mk = lambda v: pack_tb(v)
            np.savez(
                os.path.join(d, f"S{f}_1.npz"),
                mask=np.ones((n, n), np.float32),
                backbone_v37=mk(C["bg_v_37"] + C["emission_boost_v37"] * A
                                - C["max_depression_v37"] * B),
                backbone_h37=mk(C["bg_h_37"] + C["emission_boost_h37"] * A
                                - C["max_depression_h37"] * B),
                backbone_v89=mk(C["bg_v_89"] - C["max_depression_v89"] * A),
                backbone_h89=mk(C["bg_h_89"] - C["max_depression_h89"] * A),
                target_v37=mk(C["bg_v_37"] + C["emission_boost_v37"] * A
                              - C["max_depression_v37"] * B),
                target_h37=mk(C["bg_h_37"] + C["emission_boost_h37"] * A
                              - C["max_depression_h37"] * B),
                target_v89=mk(C["bg_v_89"] - C["max_depression_v89"] * A),
                target_h89=mk(C["bg_h_89"] - C["max_depression_h89"] * A))
        return sorted(_glob.glob(os.path.join(d, "*.npz")))

    def test_fitter_recovers_known_constants_from_packed_files(self):
        """Built from the CURRENT constants, so a correct fit returns them
        unchanged. Reading packed data as float would return values two
        orders of magnitude off -- which is the whole failure mode."""
        import calibrate_constants as cc
        from synthetic_algorithm import CALIBRATION as C
        res = cc.fit_from_examples(self._packed_dataset(), C)
        self.assertGreater(res.get("n_files", 0), 0)
        for k in ("bg_h_37", "emission_boost_h37", "max_depression_v89"):
            self.assertAlmostEqual(res["fitted"][k], C[k], delta=0.5,
                                   msg=f"{k} not recovered; packed data likely "
                                       f"read as Kelvin")

    def test_every_npz_reader_keys_on_dtype(self):
        """A standing guard. Any module reading backbone_/target_ arrays
        must handle uint16, or it silently works on raw counts."""
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        for module in ("calibrate_constants.py", "ml_train.py"):
            with open(os.path.join(src_dir, module), encoding="utf-8") as fh:
                src = fh.read()
            if "target_h37" not in src and "backbone_v37" not in src:
                continue
            self.assertIn("uint16", src,
                          f"{module} reads exported arrays without checking for "
                          f"packed storage")


class TestFitterCoversTheBackbone(unittest.TestCase):
    """The fit writes back into the physics, so its model must match the
    generator and its bounds must not exclude the truth."""

    def test_every_constant_lies_inside_its_own_bound(self):
        """bg_v_37 is 250 K and its bound was (170, 230). The bound went
        stale when the 0.95 emission work retuned the backgrounds, and
        nothing checked -- so the fitter CLAMPED the 37V background 20 K
        below its true value on every run, silently."""
        import calibrate_constants as cc
        from synthetic_algorithm import CALIBRATION as C
        outside = [k for k, (lo, hi) in cc.BOUNDS.items()
                   if k in C and not (lo <= C[k] <= hi)]
        self.assertEqual(outside, [],
                         f"constants outside their fitting bounds, so the fit "
                         f"would clamp them away from the truth: {outside}")

    def _dataset(self):
        import glob as _glob
        import tempfile
        from training_data_export import pack_tb
        from synthetic_algorithm import CALIBRATION as C
        rng = np.random.default_rng(1)
        d = tempfile.mkdtemp()
        for f in range(6):
            n = 44
            A = rng.uniform(0, 1, (n, n))
            B = rng.uniform(0, 1, (n, n)) * A
            A9 = rng.uniform(0, 1, (n, n))
            B9 = rng.uniform(0, 1, (n, n)) * A9
            v37 = C["bg_v_37"] + C["emission_boost_v37"] * A - C["max_depression_v37"] * B
            h37 = C["bg_h_37"] + C["emission_boost_h37"] * A - C["max_depression_h37"] * B
            v89 = C["bg_v_89"] + C["emission_boost_v89"] * A9 - C["max_depression_v89"] * B9
            h89 = C["bg_h_89"] + C["emission_boost_h89"] * A9 - C["max_depression_h89"] * B9
            np.savez(os.path.join(d, f"S{f}_1.npz"),
                     mask=np.ones((n, n), np.float32),
                     backbone_v37=pack_tb(v37), backbone_h37=pack_tb(h37),
                     backbone_v89=pack_tb(v89), backbone_h89=pack_tb(h89),
                     target_v37=pack_tb(v37), target_h37=pack_tb(h37),
                     target_v89=pack_tb(v89), target_h89=pack_tb(h89))
        return sorted(_glob.glob(os.path.join(d, "*.npz")))

    def test_recovers_all_twelve_constants(self):
        """Built from the CURRENT constants, so a correct fit returns them
        unchanged. Catches a stale bound, a model that no longer matches
        the generator, and packed data read as Kelvin, all at once."""
        import calibrate_constants as cc
        from synthetic_algorithm import CALIBRATION as C
        res = cc.fit_from_examples(self._dataset(), C)
        self.assertGreaterEqual(len(res["fitted"]), 12)
        for k, v in res["fitted"].items():
            self.assertAlmostEqual(v, C[k], delta=0.2, msg=f"{k} not recovered")

    def test_89_emission_is_fitted(self):
        """The 89 GHz fit inverted a PURE-DEPRESSION model. That matched
        the backbone until 0.133 gave 89 GHz an emission term, after which
        the recovered weight silently absorbed it and both 89 constants
        were fitted against a model the data did not come from."""
        import calibrate_constants as cc
        from synthetic_algorithm import CALIBRATION as C
        res = cc.fit_from_examples(self._dataset(), C)
        self.assertIn("emission_boost_v89", res["fitted"])
        self.assertIn("emission_boost_h89", res["fitted"])

    def test_uncovered_constants_are_named(self):
        """A constant absent from the fit is not a failure, but silence
        about it looks like one."""
        import calibrate_constants as cc
        from synthetic_algorithm import CALIBRATION as C
        res = cc.fit_from_examples(self._dataset(), C)
        self.assertIn("not_fitted", res)
        self.assertGreater(len(res["not_fitted"]), 0)


class TestFrameFetchIsBatched(unittest.TestCase):
    """Per-frame band fetches are latency-bound, so anything fetched one
    at a time costs a full round trip it need not."""

    def _mining(self):
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        with open(os.path.join(src_dir, "ml_data_mining.py"), encoding="utf-8") as fh:
            return fh.read()

    def test_no_band_is_fetched_individually_after_coverage(self):
        """Bands 9, 7 and 2 were fetched one at a time -- three separate
        round trips, each possibly a full-disk crop, for work that is
        entirely independent."""
        import re
        src = self._mining()
        singles = re.findall(r"get_band_image_any_sector\(\s*sat(?:ellite)?,\s*(\d+)", src)
        # band 13 alone is deliberate: it gates the coverage check.
        self.assertEqual([b for b in singles if b != "13"], [],
                         "a band is still fetched on its own")

    def test_band13_stays_first_and_alone(self):
        """Coverage rejection is the most common outcome, and goes_fetch
        matches on TIME ONLY -- so the check cannot be skipped, only
        moved. Fetching everything up front would undo that."""
        src = self._mining()
        self.assertIn("_goes_covers_storm(band13", src)
        i_13 = src.index("get_band_image_any_sector(\n                    sat, 13") \
            if "get_band_image_any_sector(\n                    sat, 13" in src \
            else src.index("sat, 13, t")
        i_rest = src.index("fetch_frame_bands(\n                    sat, t")
        self.assertLess(i_13, i_rest,
                        "the rest of the frame is fetched before band 13's "
                        "coverage check")

    def test_frame_fetch_returns_both_groups(self):
        import inspect
        import goes_fetch as gf
        sig = inspect.signature(gf.fetch_frame_bands)
        self.assertIn("base_bands", sig.parameters)
        self.assertIn("extra_limit", sig.parameters)


class TestCRPS(unittest.TestCase):
    """Li et al. (2026) score their synthesis with CRPS throughout. It is
    a PROPER scoring rule, so it rewards sharpness only when justified --
    unlike ensemble-mean RMSE skill, which cannot see calibration at all
    and was therefore blind to this ensemble's measured 1.95x
    overconfidence."""

    def _crps(self):
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        with open(os.path.join(src_dir, "ml_train.py"), encoding="utf-8") as fh:
            src = fh.read()
        ns = {"np": np}
        exec(src[src.index("def crps_ensemble"):src.index("def sampled_skill")], ns)
        return ns["crps_ensemble"]

    def test_minimised_when_spread_matches_truth(self):
        """The property that matters, and the one a first test of this
        missed: members were centred ON the truth, so a collapsed ensemble
        scored a perfect zero and the calibration behaviour was never
        exercised. The truth must be a DRAW from the predictive
        distribution, not its centre."""
        crps = self._crps()
        rng = np.random.default_rng(0)
        signal = rng.normal(250, 10, (80, 80))
        sigma_true = 8.0
        truth = signal + rng.normal(0, sigma_true, signal.shape)
        scores = {}
        for sm in (1.0, 4.0, 8.0, 16.0, 30.0):
            mem = np.stack([signal + rng.normal(0, sm, signal.shape)
                            for _ in range(12)])
            scores[sm] = crps(mem, truth)
        best = min(scores, key=scores.get)
        self.assertEqual(best, sigma_true,
                         f"CRPS not minimised at the true spread: {scores}")

    def test_penalises_a_confident_wrong_ensemble(self):
        crps = self._crps()
        rng = np.random.default_rng(1)
        truth = rng.normal(250, 10, (48, 48))
        tight_wrong = np.stack([truth + 15.0 + rng.normal(0, 1, truth.shape)
                                for _ in range(8)])
        honest = np.stack([truth + rng.normal(0, 8, truth.shape) for _ in range(8)])
        self.assertGreater(crps(tight_wrong, truth), crps(honest, truth))

    def test_single_member_is_mean_absolute_error(self):
        crps = self._crps()
        truth = np.array([1.0, 2.0, 3.0])
        mem = np.array([[2.0, 2.0, 2.0]])
        self.assertAlmostEqual(crps(mem, truth), float(np.mean(np.abs(mem[0] - truth))))

    def test_mask_is_honoured(self):
        crps = self._crps()
        truth = np.zeros((10, 10))
        mem = np.stack([np.where(np.arange(100).reshape(10, 10) < 50, 0.0, 99.0)
                        for _ in range(3)])
        mask = np.arange(100).reshape(10, 10) < 50
        self.assertAlmostEqual(crps(mem, truth, mask=mask), 0.0)


class TestUncertaintyReachesTheOutput(unittest.TestCase):
    """The per-pixel ensemble spread was computed and then reduced to a
    mean and a max, so the one thing it was good for -- saying WHERE the
    model is guessing -- was discarded, leaving two numbers that say only
    how much on average."""

    def _blend_spread(self, taper, n=600):
        import textwrap
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        with open(os.path.join(src_dir, "ml_inference.py"), encoding="utf-8") as fh:
            src = fh.read()
        body = textwrap.dedent(src[src.index("        def _blend_spread(spread_stack):"):
                                   src.index("        def _blend(full_arr, correction_channel):")])
        ns = {"np": np, "v37_backbone": np.zeros((n, n), np.float32),
              "taper": taper, "local_row0": 0, "local_col0": 0,
              "n_rows": 512, "n_cols": 512,
              "row0": 44, "row1": 556, "col0": 44, "col1": 556}
        exec(body, ns)
        return ns["_blend_spread"]

    def _ramp(self):
        return np.linspace(0.2, 3.0, 512)[None, None, :] * np.ones((4, 512, 512), np.float32)

    def test_field_lands_on_the_output_grid_and_varies(self):
        f = self._blend_spread(np.ones((512, 512), np.float32))(self._ramp())
        self.assertEqual(f.shape, (600, 600))
        inside = f[np.isfinite(f)]
        self.assertGreater(float(inside.max() - inside.min()), 1.0,
                           "uncertainty is a constant, so it says nothing about where")

    def test_outside_the_patch_is_nan_not_zero(self):
        """Zero would read as CERTAIN in exactly the region the model
        never looked at."""
        f = self._blend_spread(np.ones((512, 512), np.float32))(self._ramp())
        self.assertTrue(np.isnan(f[0, 0]))

    def test_tapered_edge_is_not_marked_confident(self):
        taper = np.zeros((512, 512), np.float32)
        taper[100:400, 100:400] = 1.0
        f = self._blend_spread(taper)(self._ramp())
        self.assertTrue(np.isnan(f[50, 50]))

    def test_collapsed_to_a_single_map(self):
        f = self._blend_spread(np.ones((512, 512), np.float32))(self._ramp())
        self.assertEqual(f.ndim, 2)

    def test_gui_renders_it(self):
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        with open(os.path.join(src_dir, "gui", "main_window.py"), encoding="utf-8") as fh:
            gui = fh.read()
        self.assertIn("ensemble_spread_field_k", gui)
        # and the cycle diagnostics, which reached the log only
        self.assertIn("WVIR stage", gui)


class TestEndToEndChain(unittest.TestCase):
    """Walks generate -> export -> the trainer's contract, and checks the
    checkpoint contract between training and inference.

    Each boundary is a place where a rename or a changed constant breaks
    things silently rather than loudly. The 19 -> 15 channel change was
    exactly that: it would have crashed on the first batch, after a full
    mine."""

    def _generate_and_export(self, out_dir):
        from data_types import BandImage, StormFix, MWSwath
        from synthetic_algorithm import generate_synthetic_mw
        import training_data_export as tde
        t = datetime(2022, 9, 2, 16, tzinfo=timezone.utc)
        n = 150
        lat, lon = np.mgrid[18:10:n * 1j, -64:-56:n * 1j]
        d = np.sqrt((lat - 14.0) ** 2
                    + ((lon + 60.0) * np.cos(np.radians(14.0))) ** 2) * 111.32
        ir = np.where(d < 25, 284.0, 300.0 - 110.0 * np.exp(-0.5 * (d / 90.0) ** 2))
        mk = lambda v, b: BandImage(band=b, satellite="GOES-16", scene_time=t,
                                    values=v, lat=lat, lon=lon, units="K",
                                    mesoscale_sector="M1")
        fx = StormFix(storm_id="X", valid_time=t, lat=14.0, lon=-60.0,
                      vmax_kt=115.0, mslp_mb=945.0, rmw_nm=16.0, roci_nm=240.0)
        sw = MWSwath(sensor="GMI", scene_time=t, lat=lat, lon=lon,
                     v37=np.full((n, n), 265.0), h37=np.full((n, n), 200.0),
                     v89=np.full((n, n), 270.0), h89=np.full((n, n), 255.0),
                     source_note="s")
        res = generate_synthetic_mw(mk(ir, 13), mk(ir + 3, 9), mk(ir + 6, 7), fx,
                                    real_swath=sw)
        path = tde.export_training_example(mk(ir, 13), mk(ir + 3, 9), mk(ir + 6, 7),
                                           None, fx, res, output_dir=out_dir)
        return res, path

    def test_exported_file_satisfies_the_trainer(self):
        import re
        import tempfile
        res, path = self._generate_and_export(tempfile.mkdtemp())
        with np.load(path, allow_pickle=True) as z:
            stored = set(z.files)
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        with open(os.path.join(src_dir, "ml_train.py"), encoding="utf-8") as fh:
            trn = fh.read()
        read = set(re.findall(r'data\["([a-z0-9_]+)"\]', trn))
        read |= set(re.findall(r'_load_tb\(data\["([a-z0-9_]+)"\]\)', trn))
        read |= set(re.findall(r'_surface\("([a-z0-9_]+)"', trn))
        missing = sorted(k for k in read if k not in stored)
        self.assertEqual(missing, [],
                         f"the trainer reads keys the exporter never writes: {missing}")

    def test_export_is_tagged_with_the_current_physics(self):
        import tempfile
        from synthetic_algorithm import VH_PHYSICS_ID
        res, path = self._generate_and_export(tempfile.mkdtemp())
        with np.load(path, allow_pickle=True) as z:
            self.assertEqual(str(z["vh_physics_id"]), VH_PHYSICS_ID)

    def test_targets_round_trip_through_packing(self):
        import tempfile
        from training_data_export import unpack_tb
        res, path = self._generate_and_export(tempfile.mkdtemp())
        with np.load(path, allow_pickle=True) as z:
            self.assertEqual(z["target_h37"].dtype, np.uint16)
            tb = unpack_tb(z["target_h37"])
        self.assertTrue(np.all((tb > 50) & (tb < 350)),
                        "packed targets do not unpack to physical Kelvin")

    def test_inference_verifies_the_checkpoint_contract(self):
        """in_channels and patch_sample_stride were SAVED and never
        checked. A channel change surfaced as a torch shape error; a
        STRIDE change was worse, since the shapes still match, so it
        loads cleanly and corrects the wrong ground area."""
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        with open(os.path.join(src_dir, "ml_inference.py"), encoding="utf-8") as fh:
            inf = fh.read()
        self.assertIn("MODEL_IN_CHANNELS", inf)
        self.assertIn("patch_sample_stride", inf)
        self.assertNotIn('checkpoint.get("base_channels", 32)', inf,
                         "base_channels falls back to a width training never uses")


class TestLearningCurveSubsets(unittest.TestCase):
    """Answers directly what has only ever been inferred: does more data
    still help? Bias sat near 11.5 K across 298 and then 799 examples
    while spread fell -- suggestive, but two points are not a curve.

    Also prices --max-per-storm, which deliberately shrinks the dataset to
    cut mining time."""

    def _fake_dataset(self):
        import tempfile
        d = tempfile.mkdtemp()
        for i in range(1, 17):
            storm = f"AL{i:02d}2022"
            for k in range(6):
                np.savez(os.path.join(d, f"{storm}_2022090{k}1200_GMI.npz"),
                         storm_vmax_kt=np.array(40.0 + 3 * i))
        return d

    def _subsets(self, d):
        import glob as _glob
        import random as _random
        import re
        import textwrap
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        with open(os.path.join(src_dir, "ml_train.py"), encoding="utf-8") as fh:
            src = fh.read()
        ns = {"os": os, "glob": _glob, "random": _random, "np": np,
              "DEFAULT_DATA_DIR": d}
        m = re.search(r"^INTENSITY_BANDS\s*=.*?(?=\n\w|\ndef )", src, re.S | re.M)
        exec(m.group(0), ns)
        for fn in ("def band_label", "def _storm_peak_vmax",
                   "def make_train_val_split", "def learning_curve_storm_subsets"):
            i = src.index(fn)
            j = src.index("\ndef ", i + 10)
            exec(textwrap.dedent(src[i:j]), ns)
        return ns["learning_curve_storm_subsets"](d)

    def test_subsets_are_nested(self):
        subs = self._subsets(self._fake_dataset())
        for a, b in zip(subs, subs[1:]):
            self.assertTrue(set(a["train_files"]) <= set(b["train_files"]),
                            "subsets are not nested, so the curve compares "
                            "different datasets rather than more of one")

    def test_validation_set_is_identical_across_fractions(self):
        """A curve measured against a moving target says nothing."""
        subs = self._subsets(self._fake_dataset())
        self.assertEqual(len({tuple(s["val_files"]) for s in subs}), 1)

    def test_no_storm_leaks_between_train_and_val(self):
        """Two overpasses of one hurricane hours apart are nearly the same
        picture; counting them as independent would overstate both the
        data volume and the validation score."""
        subs = self._subsets(self._fake_dataset())
        for s in subs:
            tr = {os.path.basename(f).split("_")[0] for f in s["train_files"]}
            va = {os.path.basename(f).split("_")[0] for f in s["val_files"]}
            self.assertFalse(tr & va, f"storms in both splits: {sorted(tr & va)}")

    def test_subsets_grow_with_the_fraction(self):
        subs = self._subsets(self._fake_dataset())
        counts = [s["n_storms"] for s in subs]
        self.assertEqual(counts, sorted(counts))
        self.assertLess(counts[0], counts[-1])


class TestOffsetVsStructure(unittest.TestCase):
    """Splits the correction's skill into the part a FLAT shift could
    achieve and the part that needs real structure.

    On the 0.122 run epoch 1 scored -0.201, worse than doing nothing, and
    only turned positive by epoch 3. After 0.128 removed the
    baseline-shift leak, epoch 1 starts POSITIVE -- because the residual
    now contains the systematic offset that used to be handed to the
    model, and a near-constant shift is the easiest thing a network can
    learn.

    That is the fix working. It is also a warning: skill that comes
    mostly from a flat shift is the CALIBRATION CONSTANTS' job, done
    badly and expensively by a diffusion model."""

    def _score(self, corr, truth):
        rmse_zero = float(np.sqrt((truth ** 2).mean()))
        flat = corr.mean(axis=(1, 2), keepdims=True) * np.ones_like(corr)
        full = 1 - float(np.sqrt(((corr - truth) ** 2).mean())) / rmse_zero
        offset = 1 - float(np.sqrt(((flat - truth) ** 2).mean())) / rmse_zero
        return full, offset

    def _truth(self, offset=8.0):
        rng = np.random.default_rng(0)
        structure = rng.normal(0, 1, (4, 48, 48)) * 3.0
        return offset + structure, structure

    def test_pure_offset_scores_as_entirely_flat(self):
        truth, _ = self._truth()
        full, off = self._score(np.full_like(truth, 8.0), truth)
        self.assertAlmostEqual(off / full, 1.0, delta=0.02)

    def test_structure_lowers_the_flat_share(self):
        truth, structure = self._truth()
        _, off_a = self._score(8.0 + 0.5 * structure, truth)
        full_a, _ = self._score(8.0 + 0.5 * structure, truth)
        full_b, off_b = self._score(truth.copy(), truth)
        self.assertLess(off_b / full_b, off_a / full_a,
                        "learning more structure did not reduce the flat share")

    def test_structure_without_offset_scores_poorly(self):
        """The case that matters: if the systematic offset is left
        uncorrected, structure alone buys very little."""
        truth, structure = self._truth()
        full, _ = self._score(structure.copy(), truth)
        self.assertLess(full, 0.2)

    def test_zero_mean_truth_cannot_be_helped_by_a_shift(self):
        """A first version of this test used zero-mean truth, where a
        constant shift helps by construction nothing at all -- so it
        reported 0% flat share for every input and exercised nothing."""
        rng = np.random.default_rng(1)
        truth = rng.normal(0, 3, (4, 48, 48))
        _, off = self._score(truth.copy(), truth)
        self.assertLess(abs(off), 0.05)


class TestSatelliteConsistency(unittest.TestCase):
    """Within one frame, GLM must be asked about the SAME satellite the
    bands came from.

    The streaming path selected its satellite per frame into `sat` but
    passed `satellite` to the lightning lookup -- the enclosing function's
    parameter, defaulting to GOES-19. Every frame therefore asked GOES-19
    for lightning regardless of which satellite it used: wrong for every
    East Pacific storm, and wrong for all of 2018-2024, when GOES-19 was
    not operational.

    Both names are real, so the undefined-name guard could not see it. The
    only evidence was a measured phase cost of 0.00 s -- a fetch that
    never happened."""

    def test_glm_and_bands_use_the_same_satellite_variable(self):
        import ast as _ast
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        with open(os.path.join(src_dir, "ml_data_mining.py"), encoding="utf-8") as fh:
            tree = _ast.parse(fh.read())

        def first_arg_name(call):
            if call.args and isinstance(call.args[0], _ast.Name):
                return call.args[0].id
            return None

        for fn in [n for n in _ast.walk(tree)
                   if isinstance(n, (_ast.FunctionDef, _ast.AsyncFunctionDef))]:
            bands, glm = set(), set()
            for node in _ast.walk(fn):
                if not isinstance(node, _ast.Call):
                    continue
                name = getattr(node.func, "attr", None)
                if name in ("fetch_frame_bands", "get_band_image_any_sector"):
                    n = first_arg_name(node)
                    if n:
                        bands.add(n)
                elif name == "flash_density_grid":
                    # satellite is the third positional argument here
                    if len(node.args) >= 3 and isinstance(node.args[2], _ast.Name):
                        glm.add(node.args[2].id)
            if bands and glm:
                self.assertTrue(glm <= bands,
                                f"{fn.name}() fetches bands with {sorted(bands)} "
                                f"but asks GLM about {sorted(glm)}")


class TestInferenceImportsResolve(unittest.TestCase):
    """ENSEMBLE_SPREAD_CALIBRATION was dropped from ml_inference's import
    list by a later edit to that list, while still being used in the
    diffusion branch -- with no try block around it. A NameError on the
    first diffusion inference, invisible because no diffusion frame had
    been generated since."""

    def test_every_ml_constant_used_is_imported(self):
        import ast as _ast
        import ml_constants
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        for module in ("ml_inference.py", "ml_train.py"):
            path = os.path.join(src_dir, module)
            with open(path, encoding="utf-8") as fh:
                tree = _ast.parse(fh.read(), filename=path)
            imported = set()
            for node in _ast.walk(tree):
                if isinstance(node, _ast.ImportFrom):
                    for al in node.names:
                        imported.add(al.asname or al.name)
                elif isinstance(node, _ast.Import):
                    for al in node.names:
                        imported.add((al.asname or al.name).split(".")[0])
            used = {n.id for n in _ast.walk(tree)
                    if isinstance(n, _ast.Name) and isinstance(n.ctx, _ast.Load)}
            # Anything that looks like an ml_constants setting and is used
            # here must actually have been imported.
            missing = sorted(
                n for n in used
                if n.isupper() and hasattr(ml_constants, n) and n not in imported)
            self.assertEqual(missing, [],
                             f"{module} uses ml_constants names it never "
                             f"imports: {missing}")


class TestRangedBlockSize(unittest.TestCase):
    """A live run's own log gave the number: a 0.64% crop of a full-disk
    band fetched 9.4 MB in 18 requests, for about 0.38 MB of pixels.
    512 KB blocks were tuned for TC PRIMED whole-file reads and drag in a
    large neighbourhood when the access pattern is scattered chunks."""

    def _reader(self, size, prefer_ranged, data=None):
        import io as _io
        import s3_range_reader as srr
        payload = data if data is not None else np.random.default_rng(0).bytes(size)

        class MockS3:
            def __init__(self):
                self.gets = 0
                self.bytes = 0

            def head_object(self, Bucket, Key):
                return {"ContentLength": len(payload)}

            def get_object(self, Bucket, Key, Range=None):
                self.gets += 1
                if Range is None:
                    self.bytes += len(payload)
                    return {"Body": _io.BytesIO(payload)}
                a, b = Range.split("=")[1].split("-")
                a, b = int(a), int(b)
                self.bytes += b - a + 1
                return {"Body": _io.BytesIO(payload[a:b + 1])}

        m = MockS3()
        return srr.S3RangeReader(m, "b", "k", prefer_ranged=prefer_ranged), m, payload

    def test_block_size_suits_a_strided_row_span(self):
        """REPLACES two tests built on a wrong premise.

        They asserted that ranged blocks are SMALLER than the streaming
        default and that a crop fetches far fewer bytes. Both came from
        simulating the crop as ~18 scattered 48 KB chunks, which is not
        what happens. The array is row-major and 5424 wide, so a
        434-column crop reads 434 separate rows 10848 bytes apart: the
        pixels total 0.38 MB but span a CONTIGUOUS 4.7 MB.

        The real run proved it -- going 512 KB to 128 KB moved requests
        18 -> 70 while bytes stayed at ~9 MB. Bytes have a floor set by
        the geometry, so the only thing block size controls is how many
        round trips are spent reaching it. LARGER is better, up to the
        point where overhang starts adding bytes again."""
        import io as _io
        import s3_range_reader as srr

        W, CROP = 5424, 434
        row = W * 2
        size = 30 * 1024 * 1024
        data = np.random.default_rng(0).bytes(size)
        reads = [(1190 * row + i * row + 3233 * 2, CROP * 2) for i in range(CROP)]

        class MockS3:
            def __init__(self):
                self.gets = 0
                self.bytes = 0

            def head_object(self, Bucket, Key):
                return {"ContentLength": size}

            def get_object(self, Bucket, Key, Range=None):
                self.gets += 1
                if Range is None:
                    self.bytes += size
                    return {"Body": _io.BytesIO(data)}
                a, b = Range.split("=")[1].split("-")
                a, b = int(a), int(b)
                self.bytes += b - a + 1
                return {"Body": _io.BytesIO(data[a:b + 1])}

        m = MockS3()
        r = srr.S3RangeReader(m, "b", "k", prefer_ranged=True)
        for off, n in reads:
            r.seek(off)
            self.assertEqual(r.read(n), data[off:off + n], "read is not byte-exact")

        # The real run spent 18 requests at 512 KB and 70 at 128 KB for
        # the same ~9 MB. Reaching the floor in far fewer is the point.
        self.assertLessEqual(m.gets, 12,
                             f"{m.gets} requests for one crop; block size is too "
                             f"small for a strided row-span")
        # And overhang must not start inflating the bytes again.
        self.assertLess(m.bytes / 1e6, 7.0,
                        f"{m.bytes/1e6:.2f} MB; block size is now so large it "
                        f"over-reads past the span")

    def test_whole_object_path_is_unaffected(self):
        """Small objects must still arrive in ONE request -- the 0.121
        finding that ranging them cost 30 round trips for nothing."""
        r, m, payload = self._reader(16 * 1024 * 1024, False)
        r.seek(7_000_000)
        self.assertEqual(r.read(250_000), payload[7_000_000:7_250_000])
        self.assertEqual(r.stats()["mode"], "whole")
        self.assertEqual(m.gets, 1)

    def test_block_size_attribute_does_not_shadow_the_method(self):
        """A first attempt named it self._block, which is already the
        method that FETCHES a block -- an int shadowing a callable."""
        import s3_range_reader as srr
        r, _, _ = self._reader(1024 * 1024, True)
        self.assertTrue(callable(getattr(r, "_block", None)))


class TestCrossModuleAgreement(unittest.TestCase):
    """Things that are not bugs in any one file, but disagree between
    files -- which costs output quality quietly."""

    def test_stack_width_matches_the_declared_model(self):
        """Both stacks enumerated EXTRA_IR_BANDS (7) while the layout
        declares 3, so training would have stacked 19 planes into a model
        built for 15 -- a crash on the first batch, discovered only after
        a full mine. Both now build from MODEL_EXTRA_IR_BANDS, derived
        from the layout itself."""
        from ml_constants import (MODEL_EXTRA_IR_BANDS, MODEL_IN_CHANNELS,
                                  INPUT_CHANNEL_LAYOUT)
        layout_bands = [c for c in INPUT_CHANNEL_LAYOUT if c.startswith("ir_band")]
        self.assertEqual(len(MODEL_EXTRA_IR_BANDS), len(layout_bands))
        # 3 image + N extra + 4 backbone + vmax/rmw + land/elev + flash
        self.assertEqual(3 + len(MODEL_EXTRA_IR_BANDS) + 4 + 2 + 2 + 1,
                         MODEL_IN_CHANNELS)

    def test_neither_stack_enumerates_the_full_band_list(self):
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        for module in ("ml_train.py", "ml_inference.py"):
            with open(os.path.join(src_dir, module), encoding="utf-8") as fh:
                src = fh.read()
            self.assertNotIn("for b in EXTRA_IR_BANDS", src,
                             f"{module} builds its stack from every known band, "
                             f"not the ones the model declares")

    def test_every_input_slot_is_actually_filled(self):
        """The layout spanned all 7 EXTRA_IR_BANDS while only
        EXTRA_IR_FETCH_LIMIT (3) are fetched, so FOUR channels were
        permanently neutral planes. Capacity spent on inputs that never
        carry anything, and a model taught to ignore them."""
        from ml_constants import (INPUT_CHANNEL_LAYOUT, EXTRA_IR_FETCH_LIMIT,
                                  MODEL_IN_CHANNELS)
        slots = [c for c in INPUT_CHANNEL_LAYOUT if c.startswith("ir_band")]
        self.assertEqual(len(slots), EXTRA_IR_FETCH_LIMIT,
                         "extra IR slots do not match what is fetched")
        self.assertEqual(MODEL_IN_CHANNELS, len(INPUT_CHANNEL_LAYOUT))

    def test_patch_geometry_is_self_consistent(self):
        from ml_constants import (PATCH_SIZE, PATCH_SAMPLE_STRIDE,
                                  PATCH_FOOTPRINT_PX)
        self.assertEqual(PATCH_FOOTPRINT_PX, PATCH_SIZE * PATCH_SAMPLE_STRIDE)

    def test_every_layout_channel_has_a_normalization(self):
        """A channel without an entry falls back to the global pair, which
        is the badly-conditioned behaviour per-channel norms replaced."""
        from ml_constants import INPUT_CHANNEL_LAYOUT, CHANNEL_NORM
        missing = [c for c in INPUT_CHANNEL_LAYOUT
                   if c not in CHANNEL_NORM
                   and c not in ("vmax", "rmw", "land_fraction", "elevation",
                                 "flash_density")]
        self.assertEqual(missing, [], f"no CHANNEL_NORM entry for {missing}")

    def test_fitted_params_match_what_the_fit_returns(self):
        """PARAMS_89 is used by tests and reporting to enumerate coverage;
        if it lags what the fit actually solves for, coverage looks
        smaller than it is."""
        import calibrate_constants as cc
        from synthetic_algorithm import CALIBRATION as C
        for k in list(cc.PARAMS_37) + list(cc.PARAMS_89):
            self.assertIn(k, C, f"{k} is fitted but not a CALIBRATION key")
            self.assertIn(k, cc.BOUNDS, f"{k} is fitted with no bound")


class TestRetiredGuiSettings(unittest.TestCase):
    """Three settings removed or defaulted off. Checked at source level
    because the GUI needs Qt, which this suite does not load."""

    def _gui(self):
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        with open(os.path.join(src_dir, "gui", "main_window.py"),
                  encoding="utf-8") as fh:
            return fh.read()

    def test_nexrad_checkbox_is_gone(self):
        """NEXRAD was retired in 0.112 with arm_pyart commented out of
        requirements; the checkbox offered a toggle for a path that could
        no longer run."""
        self.assertNotIn("radar_check_checkbox", self._gui())

    def test_paired_export_checkbox_is_gone(self):
        """A 0.65-era holdover from before ml_data_mining existed.
        Training data now comes from a pipeline that is reproducible,
        vintage-tagged and resumable; a one-off export was none of those."""
        self.assertNotIn("export_training_data_check", self._gui())

    def test_sector_selector_is_m1_m2_only(self):
        """"Auto (either)" passed sector=None, and find_nearest_file
        matches on TIME ONLY -- so it returned whichever mesoscale box
        scanned closest to the requested moment, regardless of where that
        box was pointed. M1 and M2 are independently steerable and
        routinely sit over different storms, so the option could quietly
        return a scene of somewhere else."""
        src = self._gui()
        self.assertIn('addItems(["M1", "M2"])', src)
        self.assertNotIn('startswith("Auto")', src)

    def test_gui_checks_the_sector_contains_the_storm(self):
        """The mining path has validated coverage since 0.98; the GUI
        never did. A valid, recent file from the wrong sector renders a
        convincing frame of the wrong storm with no error at all -- and
        with the sector now chosen explicitly, a wrong pick is easier to
        make."""
        self.assertIn("_image_covers(band13", self._gui())

    def test_novelty_taper_defaults_off(self):
        """Tapering suppresses the correction exactly where the backbone
        is least trustworthy -- the rare and oddly-structured storms that
        are the ones worth looking at."""
        self.assertIn("self.ml_novelty_checkbox.setChecked(False)", self._gui())


class TestSectorConsistency(unittest.TestCase):
    """Every band in a frame must come from the SAME sector. If band 13
    falls back to full disk while bands 9/7/2 stay on mesoscale, the
    channels arrive on different grids -- which does not raise, it just
    produces a frame built from mismatched geometry."""

    def test_mining_routes_every_band_through_the_fallback(self):
        src_dir = os.path.join(os.path.dirname(__file__), "..", "src")
        with open(os.path.join(src_dir, "ml_data_mining.py"), encoding="utf-8") as fh:
            src = fh.read()
        import re
        # No band may still use the mesoscale-only entry point.
        leftover = re.findall(r"goes_fetch\.get_band_image\((?!_)", src)
        self.assertEqual(leftover, [],
                         "a band still uses the mesoscale-only fetch; it can land "
                         "on a different grid than the rest of the frame")

    def test_extra_bands_accept_a_centre(self):
        """The supplementary IR bands need the storm centre to follow the
        same fallback; without it they silently stay mesoscale-only."""
        import inspect
        import goes_fetch as gf
        params = inspect.signature(gf.fetch_extra_ir_bands).parameters
        self.assertIn("center_lat", params)
        self.assertIn("center_lon", params)

    def test_fallback_prefers_mesoscale(self):
        """Mesoscale is 1-minute cadence and a small whole-file read;
        full disk is 10-minute and needs a ranged crop. Preferring full
        disk would be slower and coarser for the majority of cases meso
        already covers."""
        import inspect
        import goes_fetch as gf
        src = inspect.getsource(gf.get_band_image_any_sector)
        self.assertLess(src.index("get_band_image("), src.index("RadF"))


class TestProductParsing(unittest.TestCase):
    def test_all_three_products_parse(self):
        import goes_fetch as gf
        cases = [("OR_ABI-L1b-RadM1-M6C13_G18_s20242451230123_e1_c1.nc", "M1"),
                 ("OR_ABI-L1b-RadM2-M6C13_G18_s20242451230123_e1_c1.nc", "M2"),
                 ("OR_ABI-L1b-RadC-M6C13_G16_s20242451230123_e1_c1.nc", "C"),
                 ("OR_ABI-L1b-RadF-M6C13_G16_s20242451230123_e1_c1.nc", "F")]
        for fname, sector in cases:
            ref = gf._parse_key("a/b/" + fname, "GOES-16")
            self.assertIsNotNone(ref, fname)
            self.assertEqual(ref.band, 13)
            self.assertEqual(ref.sector, sector)

    def test_non_l1b_products_are_ignored(self):
        import goes_fetch as gf
        self.assertIsNone(gf._parse_key("a/OR_ABI-L2-CMIPF-M6C13_G16_s2024245.nc",
                                        "GOES-16"))


class TestCompactStorage(unittest.TestCase):
    def test_tb_roundtrip_is_finer_than_sensor_noise(self):
        import training_data_export as tde
        rng = np.random.default_rng(3)
        a = rng.uniform(80, 330, (64, 64)).astype(np.float32)
        a[rng.random(a.shape) < 0.05] = np.nan
        u = tde.unpack_tb(tde.pack_tb(a))
        good = np.isfinite(a)
        self.assertLess(float(np.nanmax(np.abs(a[good] - u[good]))), 0.02)
        np.testing.assert_array_equal(np.isnan(a), np.isnan(u))

    def test_halves_the_bytes(self):
        import training_data_export as tde
        a = np.full((128, 128), 250.0, dtype=np.float32)
        self.assertEqual(tde.pack_tb(a).nbytes * 2, a.nbytes)


class TestSurfaceType(unittest.TestCase):
    """Ocean constants applied over land don't just mis-level the field --
    a warm, unpolarized surface is exactly what heavy rain looks like over
    ocean, so unmasked land imitates the feature being detected."""

    def test_land_gets_land_background(self):
        import surface_type
        original = surface_type.land_fraction
        surface_type.land_fraction = lambda lat, lon, progress_callback=None: (
            (np.asarray(lon) > -93.0).astype(np.float32))
        try:
            n = 150
            lat, lon = np.mgrid[10:20:n * 1j, -100:-88:n * 1j]
            d = np.sqrt((lat - 15.0) ** 2
                        + ((lon + 95.0) * np.cos(np.radians(15.0))) ** 2) * 111.32
            ir = np.where(d < 20, 282.0, 300.0 - 108.0 * np.exp(-0.5 * (d / 110.0) ** 2))
            r = generate(lat, lon, ir, fix_at(0, 15.0, -95.0))
            ocean = (lon < -96) & (d > 400)
            land = (lon > -90) & (d > 400)
            pol_ocean = float((r.v37 - r.h37)[ocean].mean())
            pol_land = float((r.v37 - r.h37)[land].mean())
            self.assertGreater(pol_ocean, 40.0, "ocean should be strongly polarized")
            self.assertLess(pol_land, 15.0, "land should be nearly unpolarized")
            self.assertGreater(float(r.h37[land].mean()), 250.0,
                               "land H-pol should sit near the physical temperature")
        finally:
            surface_type.land_fraction = original

    def test_missing_backend_falls_back_to_ocean(self):
        """No mask available must reproduce the old behaviour, not fail."""
        import surface_type
        saved = surface_type._BACKEND
        surface_type._BACKEND = "none"
        try:
            lat, lon = np.mgrid[10:20:20j, -100:-90:20j]
            lf = surface_type.land_fraction(lat, lon)
            self.assertEqual(lf.shape, lat.shape)
            self.assertTrue(np.all(lf == 0.0))
        finally:
            surface_type._BACKEND = saved


class TestStructureMetrics(unittest.TestCase):
    """The eyewall radius was located on the CLIPPED redness field, so a
    saturated core made it report where clipping began."""

    def _field(self, redness, freq=37):
        lo, hi = msm.COLOR_COMPOSITE_SPEC[freq]["red_range"]
        theta = msm.COLOR_RED_THETA[freq]
        pct = hi - redness * (hi - lo)
        v = 250.0 * np.ones_like(pct)
        return v, ((1.0 + theta) * v - pct) / theta

    def _grid(self, n=400):
        lat, lon = np.mgrid[25:35:n * 1j, -100:-90:n * 1j]
        return lat, lon, msm._distance_km(lat, lon, 30.0, -95.0)

    def test_ring_radius_recovered(self):
        lat, lon, r = self._grid()
        v, h = self._field(np.exp(-0.5 * ((r - 40.0) / 12.0) ** 2))
        s = msm.structure_metrics(v, h, 37, lat, lon, 30.0, -95.0, rmw_km=40.0)
        self.assertAlmostEqual(s["eyewall_radius_km"], 40.0, delta=6.0)

    def test_saturated_ring_radius_still_recovered(self):
        lat, lon, r = self._grid()
        v, h = self._field(np.exp(-0.5 * ((r - 40.0) / 12.0) ** 2) * 3.0)
        s = msm.structure_metrics(v, h, 37, lat, lon, 30.0, -95.0, rmw_km=40.0)
        self.assertAlmostEqual(s["eyewall_radius_km"], 40.0, delta=6.0)
        self.assertGreater(s["saturated_annulus_km"], 0.0)

    def test_disc_has_no_eye_contrast(self):
        lat, lon, r = self._grid()
        v, h = self._field((r < 60).astype(float) * 3.0 + 0.05)
        s = msm.structure_metrics(v, h, 37, lat, lon, 30.0, -95.0, rmw_km=40.0)
        self.assertLess(s["eye_contrast"], 0.05)

    def test_suppresses_radius_when_no_core(self):
        lat, lon, r = self._grid()
        ring, _ = self._field(np.exp(-0.5 * ((r - 40.0) / 12.0) ** 2))
        rv, rh = self._field(np.exp(-0.5 * ((r - 40.0) / 12.0) ** 2))
        ev, eh = self._field(np.zeros_like(r))
        a = msm.structure_metrics(ev, eh, 37, lat, lon, 30.0, -95.0, rmw_km=40.0)
        b = msm.structure_metrics(ev, eh, 37, lat, lon, 30.0, -95.0, rmw_km=40.0)
        self.assertIn("not meaningful", msm.compare_structure(a, b))

    def test_warns_on_signature_suppression_not_on_eye_opening(self):
        lat, lon, r = self._grid()
        ring = self._field(np.exp(-0.5 * ((r - 40.0) / 12.0) ** 2))
        disc = self._field((r < 60).astype(float) * 3.0 + 0.05)
        s_ring = msm.structure_metrics(*ring, 37, lat, lon, 30.0, -95.0, rmw_km=40.0)
        s_disc = msm.structure_metrics(*disc, 37, lat, lon, 30.0, -95.0, rmw_km=40.0)
        s_warm = msm.structure_metrics(ring[0] + 18.0, ring[1] + 18.0, 37,
                                       lat, lon, 30.0, -95.0, rmw_km=40.0)
        self.assertNotIn("WARNING", msm.compare_structure(s_disc, s_ring),
                         "flagged a disc->ring improvement as a failure")
        self.assertIn("WARNING", msm.compare_structure(s_ring, s_warm),
                      "missed a signature pushed out of the colour window")


class TestCenterFix(unittest.TestCase):
    """Ad-hoc versions of this kept locking onto gaps in the cirrus."""

    def _scene(self, n=300, clat=13.5, clon=-152.5, eye_km=20.0):
        lat, lon = np.mgrid[18:9:n * 1j, -158:-148:n * 1j]
        d = np.sqrt((lat - clat) ** 2
                    + ((lon - clon) * np.cos(np.radians(clat))) ** 2) * 111.32
        tb = np.where(d < eye_km, 280.0, 300.0 - 110.0 * np.exp(-0.5 * (d / 120.0) ** 2))
        return lat, lon, tb

    def test_finds_eye(self):
        lat, lon, tb = self._scene()
        r = tc_center_fix.detect_center(tb, lat, lon, 13.5, -152.5)
        self.assertEqual(r["method"], "eye")
        self.assertLess(r["offset_km"], 10.0)

    def test_converges_from_offset_priors(self):
        lat, lon, tb = self._scene()
        found = set()
        for plat, plon in [(13.9, -151.9), (13.1, -153.1), (14.2, -152.5), (13.5, -151.6)]:
            r = tc_center_fix.detect_center(tb, lat, lon, plat, plon)
            self.assertIsNotNone(r)
            found.add((round(r["lat"], 1), round(r["lon"], 1)))
        self.assertEqual(len(found), 1, f"converged on different points: {found}")

    def test_ignores_off_grid_corners(self):
        """A GOES crop is a parallelogram in a rectangular array; the white
        corners are 'enclosed by cloud' and used to win as giant eyes."""
        lat, lon, tb = self._scene()
        tb[:40, :40] = np.nan
        tb[:40, -40:] = np.nan
        r = tc_center_fix.detect_center(tb, lat, lon, 13.5, -152.5)
        self.assertEqual(r["method"], "eye")
        self.assertLess(r["offset_km"], 20.0)

    def test_reports_offset_when_prior_is_wrong(self):
        lat, lon, tb = self._scene()
        r = tc_center_fix.detect_center(tb, lat, lon, 13.5, -151.7)
        self.assertGreater(r["offset_km"], 50.0)

    def test_no_eye_degrades_to_low_confidence(self):
        lat, lon, tb = self._scene(eye_km=0.0)
        r = tc_center_fix.detect_center(tb, lat, lon, 13.5, -152.5)
        self.assertEqual(r["method"], "cdo_centroid")
        self.assertLess(r["confidence"], 0.5)

    def test_no_cloud_returns_none(self):
        lat, lon, _ = self._scene()
        self.assertIsNone(tc_center_fix.detect_center(
            np.full(lat.shape, 300.0), lat, lon, 13.5, -152.5))


class TestCalibrationState(unittest.TestCase):
    """Offsets learned against a superseded baseline must not survive a
    baseline change, or the correction double-counts."""

    def setUp(self):
        import tempfile
        self._orig = calibration_state.STATE_PATH
        self._dir = tempfile.mkdtemp()
        calibration_state.STATE_PATH = os.path.join(self._dir, "cal.json")
        calibration_state.LAST_LOAD_WAS_RESET.update({"reset": False, "old_id": None})

    def tearDown(self):
        calibration_state.STATE_PATH = self._orig

    def test_stale_baseline_is_discarded(self):
        import json
        with open(calibration_state.STATE_PATH, "w") as f:
            json.dump({"offset_37": -36.8, "offset_89": -16.5,
                       "n_updates_37": 54, "n_updates_89": 54}, f)
        state = calibration_state.load_state()
        self.assertEqual(state["offset_37"], 0.0)
        self.assertIn("RESET", calibration_state.get_status_summary())

    def test_matching_baseline_is_kept(self):
        import json
        with open(calibration_state.STATE_PATH, "w") as f:
            json.dump({"offset_37": -2.5, "offset_89": -1.0,
                       "n_updates_37": 3, "n_updates_89": 3,
                       "baseline_id": calibration_state.CALIBRATION_BASELINE_ID}, f)
        self.assertAlmostEqual(calibration_state.load_state()["offset_37"], -2.5)

    def test_offset_is_clamped(self):
        for _ in range(50):
            calibration_state.update_offset(37, -500.0)
        self.assertLessEqual(abs(calibration_state.load_state()["offset_37"]),
                             calibration_state.MAX_OFFSET_K + 1e-6)

    def test_corrupt_state_file_recovers(self):
        with open(calibration_state.STATE_PATH, "w") as f:
            f.write("{not json")
        self.assertEqual(calibration_state.load_state()["offset_37"], 0.0)


class TestMLInference(unittest.TestCase):
    """Strength must be a linear dial, and the PCT clamp must bound the
    space the composites are actually rendered in."""

    def setUp(self):
        import ml_inference
        self.mi = ml_inference
        self._orig_loader = ml_inference._load_model_cached
        from ml_constants import PATCH_SIZE, TB_STD

        class _T:
            def __init__(self, a): self.a = a
            def __getitem__(self, i): return _T(self.a[i])
            def cpu(self): return self
            def numpy(self): return self.a

        class _N:
            def __init__(self, a): self.a = a
            def unsqueeze(self, d): return _N(np.expand_dims(self.a, d))
            def to(self, d): return self.a
            @property
            def shape(self): return self.a.shape

        class _NG:
            def __enter__(self): return None
            def __exit__(self, *a): return False

        import types
        sys.modules["torch"] = types.SimpleNamespace(
            from_numpy=lambda a: _N(a), no_grad=lambda: _NG())

        class Fake:
            def __call__(self, t):
                out = np.zeros((1, 4, PATCH_SIZE, PATCH_SIZE), np.float32)
                out[:, 0] = 60.0 / TB_STD
                out[:, 1] = -60.0 / TB_STD
                out[:, 2] = 60.0 / TB_STD
                out[:, 3] = 60.0 / TB_STD
                return _T(out)

        ml_inference._load_model_cached = lambda p=None: (Fake(), "cpu")

    def tearDown(self):
        self.mi._load_model_cached = self._orig_loader

    def _run(self, **kw):
        n = 400
        z = np.full((n, n), 250.0)
        lat, lon = np.mgrid[10:20:n * 1j, -100:-90:n * 1j]
        st = {}
        v37, h37, _, _ = self.mi.apply_ml_correction(
            z, z, z, z.copy(), z.copy(), z.copy(), z.copy(), lat, lon,
            storm_lat=15.0, storm_lon=-95.0, storm_vmax_kt=90.0, storm_rmw_nm=25.0,
            stats_out=st, **kw)
        return v37, h37, st

    def test_strength_is_linear(self):
        full, _, _ = self._run(strength=1.0, max_pct_k=0)
        half, _, _ = self._run(strength=0.5, max_pct_k=0)
        d_full = full[200, 200] - 250.0
        d_half = half[200, 200] - 250.0
        self.assertAlmostEqual(d_half, d_full / 2.0, places=3,
                               msg="strength is not a linear dial (clamped before scaling?)")

    def test_strength_zero_is_a_noop(self):
        v, _, st = self._run(strength=0.0)
        self.assertFalse(st["applied"])
        np.testing.assert_allclose(v, 250.0)

    def test_pct_clamp_bounds_the_colour_space(self):
        _, _, off = self._run(strength=1.0, max_pct_k=0)
        _, _, on = self._run(strength=1.0, max_pct_k=12.0)
        self.assertGreater(off["pct_peak_37_pctwindow"], 200.0)
        self.assertLess(on["pct_peak_37_k"], 12.5)

    def test_channel_clamp_respected(self):
        v, h, _ = self._run(strength=1.0, max_correction_k=25.0, max_pct_k=0)
        self.assertLessEqual(abs(v[200, 200] - 250.0), 25.0 + 1e-6)

    def test_rmw_fallback_prefers_backbone_value(self):
        n = 400
        z = np.full((n, n), 250.0)
        lat, lon = np.mgrid[10:20:n * 1j, -100:-90:n * 1j]
        st = {}
        self.mi.apply_ml_correction(
            z, z, z, z.copy(), z.copy(), z.copy(), z.copy(), lat, lon,
            storm_lat=15.0, storm_lon=-95.0, storm_vmax_kt=50.0, storm_rmw_nm=None,
            fallback_rmw_nm=4.86, stats_out=st)
        self.assertAlmostEqual(st["rmw_nm_used"], 4.86, places=2)
        self.assertEqual(st["rmw_source"], "backbone-fallback")

    def test_out_of_bounds_padding_is_in_distribution(self):
        """Zero-fill normalized to about -6 sigma, a value never seen in
        training, presented as a hard edge against real data."""
        from ml_constants import TB_MEAN
        n = 200  # smaller than PATCH_SIZE, so padding is guaranteed
        z = np.full((n, n), 250.0)
        lat, lon = np.mgrid[10:20:n * 1j, -100:-90:n * 1j]
        captured = {}

        class Cap:
            def __call__(self, t):
                captured["in"] = np.asarray(t)
                from ml_constants import PATCH_SIZE
                class _T2:
                    def __init__(self, a): self.a = a
                    def __getitem__(self, i): return _T2(self.a[i])
                    def cpu(self): return self
                    def numpy(self): return self.a
                return _T2(np.zeros((1, 4, PATCH_SIZE, PATCH_SIZE), np.float32))

        self.mi._load_model_cached = lambda p=None: (Cap(), "cpu")
        self.mi.apply_ml_correction(z, z, z, z.copy(), z.copy(), z.copy(), z.copy(),
                                    lat, lon, storm_lat=10.2, storm_lon=-99.8,
                                    storm_vmax_kt=90.0, storm_rmw_nm=20.0)
        pad = captured["in"][0][0, 0, 0]
        self.assertLess(abs(float(pad)), 1.0,
                        f"padding normalized to {pad:.2f} sigma; should be near 0")


class TestFusionMath(unittest.TestCase):
    def test_weighted_fuse_renormalizes(self):
        from synthetic_algorithm import _weighted_fuse
        a = np.full((10, 10), 100.0)
        b = np.full((10, 10), 200.0)
        fused, cov = _weighted_fuse({"x": a, "y": b}, {"x": 1.0, "y": 3.0})
        np.testing.assert_allclose(fused, 175.0)

    def test_missing_source_renormalizes(self):
        from synthetic_algorithm import _weighted_fuse
        a = np.full((10, 10), 100.0)
        fused, _ = _weighted_fuse({"x": a, "y": None}, {"x": 1.0, "y": 3.0})
        np.testing.assert_allclose(fused, 100.0)

    def test_no_valid_source_is_nan_not_zero(self):
        """0 K is finite, so assert_finite would not catch it, and it
        renders as fully saturated red."""
        from synthetic_algorithm import _weighted_fuse
        a = np.full((4, 4), np.nan)
        fused, _ = _weighted_fuse({"x": a}, {"x": 1.0})
        self.assertTrue(np.all(np.isnan(fused)))

    def test_ml_contribution_is_exactly_recoverable(self):
        """The single-run A/B relies on the fuse being linear in the
        backbone with value-independent weights."""
        from synthetic_algorithm import _weighted_fuse
        rng = np.random.default_rng(0)
        pre = rng.normal(250, 10, (40, 40))
        delta = rng.normal(0, 8, (40, 40))
        mw = rng.normal(240, 10, (40, 40))
        mw[rng.random((40, 40)) < 0.4] = np.nan
        w = {"backbone": 0.1, "mw": 0.045}
        post, _ = _weighted_fuse({"backbone": pre + delta, "mw": mw}, w)
        truth, _ = _weighted_fuse({"backbone": pre, "mw": mw}, w)
        zeros = np.where(np.isfinite(mw), 0.0, np.nan)
        contrib, _ = _weighted_fuse({"backbone": delta, "mw": zeros}, w)
        np.testing.assert_allclose(post - contrib, truth, atol=1e-9)


class TestComposites(unittest.TestCase):
    def test_colour_tables_bounded(self):
        import mw_composites
        v = np.linspace(100, 320, 500).reshape(20, 25)
        h = v - 40.0
        for fn in (mw_composites.build_37_color_composite,
                   mw_composites.build_89_color_composite):
            rgb = fn(v, h)
            self.assertTrue(np.all((rgb >= 0) & (rgb <= 255)),
                            f"{fn.__name__} produced out-of-range RGB")
            self.assertTrue(np.all(np.isfinite(rgb)))


if __name__ == "__main__":
    unittest.main(verbosity=2)
